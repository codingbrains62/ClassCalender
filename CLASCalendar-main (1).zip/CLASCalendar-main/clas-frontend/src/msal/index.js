import * as Msal from 'msal'
import config from '../config'
import axios from 'axios'
const schedule = require('node-schedule');
export default class AuthService {
  constructor() {
    let redirectUri = config.redirecturl
    let PostLogoutRedirectUri = '/'
    this.graphUrl = config.graphendpoint
    this.applicationConfig = {
      clientID: config.clientid,
      authority: config.authority,
      graphScopes: config.graphscopes
    }
    this.app = new Msal.UserAgentApplication(
      this.applicationConfig.clientID,
      this.applicationConfig.authority,

      () => {
        // callback for login redirect

      },
      {
        redirectUri
      }
    )
  }
  // Core Functionality
  loginPopup() {
    return this.app.loginPopup(this.applicationConfig.graphScopes).then(
      idToken => {
        const user = this.app.getUser();
        if (user) {
          return user;
        } else {
          return null;
        }
      },
      () => {
        return null;
      }
    );
  }
  loginRedirect() {
    this.app.loginRedirect(this.applicationConfig.graphScopes);
  }
  logout() {
    this.app._user = null
    this.app.logout()
  }
  // Graph Related
  getGraphToken() {
    return this.app.acquireTokenSilent(this.applicationConfig.graphScopes).then(
      accessToken => {
        localStorage.setItem('GraphToken', accessToken);
        return accessToken;
      },
      error => {
        return this.app
          .acquireTokenPopup(this.applicationConfig.graphScopes)
          .then(
            accessToken => {
              return accessToken;
            },
            err => {
              console.error(err);
            }
          );
      }
    );
  }
  getData() {
  }
  getGraphUserInfo(token) {
    const headers = new Headers({ Authorization: `Bearer ${token}` });
    const options = {
      headers,
    };
    console.log(options)
    return fetch(`${this.graphUrl}/calendar/events`, options)
      .then(response => response.json())
      .catch(response => {
        throw new Error(response.text());
      });
  }
  CreateEvent(data_arr) {
    return this.getGraphToken().then(
      token => {
        localStorage.setItem('GraphToken', token);
        var data = {
          "reminderMinutesBeforeStart": 15,
          "isReminderOn": true,
          "hasAttachments": false,
          "hideAttendees": false,
          "subject": data_arr.Subject,
          "bodyPreview": data_arr.Description,
          "recurrence": data_arr.RecurrenceRule,
          "body": {
            "contentType": "html",
            "content": data_arr.email_body
          },
          "start": {
            "dateTime": new Date(data_arr.StartTime).toUTCString(),
            "timeZone": 'UTC',
          },
          "end": {
            "dateTime": new Date(data_arr.EndTime).toUTCString(),
            "timeZone": 'UTC',
          },
          "location": {
            "displayName": data_arr.Location,
            "locationType": "default",
            "uniqueId": "Harry's Bar",
            "uniqueIdType": "private"
          },
          "locations": [
            {
              "displayName": "Harry's Bar",
              "locationType": "default",
              "uniqueIdType": "unknown"
            }
          ],
          "recurrence": null,
          "attendees": [
            {
              "emailAddress": {
                "name": data_arr.email_subject + '&' + data_arr.email_to,
              }
            }
          ],
          "organizer": {
            "emailAddress": {
              "name": data_arr.email_subject,
              "address": data_arr.email_to
            }
          }
        }
        const headers = {
          "Authorization": `Bearer ${token}`,
          'Content-type': 'application/json'
        };
        var res = '';
        return axios.post(`${this.graphUrl}/calendar/events`, data, { headers })
          .then((response) => {
            return response.data
          }, (error) => {
            console.log(error);
          })
      }, error => {
        console.error(error);
      });
  }
  getUser() {
    return this.app.getUser();
  }
  UpdateEvent(data_arr) {
    var user = this.getUser();
    if (user == null) {
      var parameters = {
        id: data_arr.Id,
        subjectName: data_arr.Subject,
        startTime: data_arr.StartTime,
        endTime: data_arr.EndTime,
        location: data_arr.Location,
        allData: data_arr.allData,
        recurrence: data_arr.recurrence == null ? '' : data_arr.recurrence,
        reminderMinutesBeforeStart: data_arr.reminderMinutesBeforeStart,
        isAllDay: data_arr.isAllDay,
        isReminderOn: data_arr.isReminderOn,
        email_id: data_arr.email_id,
        email_subject: data_arr.email_subject,
        email_body: data_arr.email_body,
        userid: localStorage.getItem('userid')
      }
      axios.post('/api/update-calendar', parameters).then((response) => {
        if (response.data.record.status_code == 200) {
          this.$toast.success({ message: response.data.record.message });
          // localStorage.setItem('lastSegment', 0)
          // this.Alldataget();
        } else if (response.data.record.status_code == 202) {
          this.$toast.error({ message: response.data.record.message })
        }
        else if (response.data.record.status_code == 500) {
          this.$toast.error({ message: response.data.record.message })
        }
      }, (error) => { console.error(error) })
    } else {
      return this.getGraphToken().then(
        token => {
          localStorage.setItem('GraphToken', token);
          var data = {
            "reminderMinutesBeforeStart": 15,
            "isReminderOn": true,
            "hasAttachments": false,
            "hideAttendees": false,
            "subject": data_arr.Subject,
            "bodyPreview": data_arr.Description,
            "importance": "normal",
            "sensitivity": "normal",
            "isAllDay": data_arr.IsAllDay,
            "isCancelled": false,
            "isDraft": false,
            "isOrganizer": true,
            "responseRequested": true,
            "seriesMasterId": null,
            "showAs": "busy",
            "type": "singleInstance",
            "onlineMeetingUrl": null,
            "recurrence": data_arr.RecurrenceRule,
            "isOnlineMeeting": false,
            "onlineMeetingProvider": "unknown",
            "onlineMeeting": null,
            "allowNewTimeProposals": true,
            "responseStatus": {
              "response": "organizer",
              "time": "0001-01-01T00:00:00Z"
            },
            "body": {
              "contentType": "html",
              "content": data_arr.email_body
            },
            "start": {
              "dateTime": new Date(data_arr.StartTime),
              "timeZone": 'Pacific Standard Time',
            },
            "end": {
              "dateTime": new Date(data_arr.EndTime),
              "timeZone": 'Pacific Standard Time',
            },
            "location": {
              "displayName": "Harry's Bar",
              "locationType": "default",
              "uniqueId": "Harry's Bar",
              "uniqueIdType": "private"
            },
            "locations": [
              {
                "displayName": "Harry's Bar",
                "locationType": "default",
                "uniqueIdType": "unknown"
              }
            ],
            "recurrence": null,
            "attendees": [
              {
                "emailAddress": {
                  "name": data_arr.email_subject == 'undefind' & data_arr.email_to
                    == 'undefind' ? "" : data_arr.email_subject + '&' + data_arr.email_to
                }
              }
            ],
            "organizer": {
              "emailAddress": {
                "name": data_arr.email_subject,
                "address": data_arr.email_to
              }
            }
          }
          const headers = {
            "Authorization": `Bearer ${token}`,
            'Content-type': 'application/json'
          };
          return axios.patch(`${this.graphUrl}/calendar/events/${data_arr.Id}`, data, { headers })
            .then((response) => {
              this.reminderEmail(response);
              return response.data
            }, (error) => {
              console.log(error);
            })
        }, error => {
          console.error(error);
        })
    }
  }
  DeleteEvent(data_arr) {
    var user = this.getUser();
    if (user == null) {
      axios.post('/api/delete-calendar', { id: data_arr[0].Id }).then((response) => {
        if (response.data.record.status_code == 200) {
          this.$toast.success({ message: response.data.record.message });
          this.Alldataget();
        } else if (response.data.record.status_code == 202) {
          this.$toast.error({ message: response.data.record.message })
        }
        else if (response.data.record.status_code == 500) {
          this.$toast.error({ message: response.data.record.message })
        }
      },
        (error) => {
          console.error(error)
        })
    } else {
      this.getGraphToken().then(
        token => {
          localStorage.setItem('GraphToken', token);
          const headers = {
            "Authorization": `Bearer ${token}`,
          };
          axios.delete(`${this.graphUrl}/calendar/events/${data_arr[0].Id}`, { headers })
            .then((response) => {
              return response.data
            }, (error) => {
              console.log(error);
            })
        }, error => {
          console.error(error);
        })
    }
  }
  //all id search data here....
  async AllIdSearch(){
    var user = this.getUser();
    if (user == null) {
      var userid = localStorage.getItem('userid')
      return axios.post('/api/idsearch-get', { user: userid })
        .then((response) => {
          var data_array = [];
          data_array = response.data.message;
          var item = [];
          for (let i = 0; i < data_array.length; i++) {
            const element = data_array[i].id;
            // console.log(element === undefined)
            if (element === undefined) {
              var dateUTC = new Date(value.starttime);
              var dateUTC = dateUTC.getTime()
              var dateIST = new Date(dateUTC);
              dateIST.setHours(dateIST.getHours()+5 );
              dateIST.setMinutes(dateIST.getMinutes()+30 );
              var dateUTCend = new Date(value.endtime);
              var dateUTCend = dateUTCend.getTime()
              var dateISTend = new Date(dateUTCend);
              dateISTend.setHours(dateISTend.getHours()+5);
              dateISTend.setMinutes(dateISTend.getMinutes()+30);
              arr = {
                id:data_array[i].id,
                title: data_array[i].title,
                startCalendar: data_array[i].startCalendar,
                endCalendar: data_array[i].endCalendar,
                // starttime: data_array[i].starttime,
                // endtime: data_array[i].endtime,
                areadescription: data_array[i].areadescription,
                userid: localStorage.getItem('userid')
              }
            }
            else {
           var arr = {
                id:data_array[i].id,
                title: data_array[i].title,
                startCalendar: data_array[i].startCalendar,
                endCalendar: data_array[i].endCalendar,
                // starttime: data_array[i].starttime,
                // endtime: data_array[i].endtime,
                areadescription: data_array[i].areadescription,
                userid: localStorage.getItem('userid')
              }
            }
            item.push(arr);
            // console.log(item)
          }
          
          return item;
         
        },
          (error) => {
            console.error(error)
          })
    }else {
      return this.getGraphToken().then(
        token => {
          localStorage.setItem('GraphToken', token);
          return this.getGraphUserInfo(token).then(
            data => {
              var data_list = [];
              for (var i = 0; i < data.value.length; i++) {
                var arr = {
                  id:data_list[i].id,
                  title: data_list[i].title,
                  startCalendar: data_list[i].startCalendar,
                  endCalendar: data_list[i].endCalendar,
                  // starttime: data_list[i].starttime,
                  // endtime: data_list[i].endtime,
                  areadescription: data_list[i].areadescription,
                }
                data_list.push(arr);
            //  console.log(data_list)
             }                     
              data.value.map(res => {
                if (res.attendees.length > 0) {
                  var dateTime_arr = res.start.dateTime.split("T");
                  var date_arr = dateTime_arr[0].split('-');
                  var time_arrplusdot = dateTime_arr[1].split('.');
                  var time_arr = time_arrplusdot[0].split(':');
                  const rule = new schedule.RecurrenceRule();
                  rule.hour = parseInt(time_arr[0]);
                  rule.minute = parseInt((time_arr[1].substr(1, 1)) + 15);
                  rule.second = parseInt(time_arr[2].substr(1, 1));
                  rule.date = parseInt(date_arr[2]);
                  rule.month = parseInt(((date_arr[1].substr(1, 1)) - 1));
                  rule.year = parseInt(date_arr[0]);
                  const job = schedule.scheduleJob(rule, function () {
                    var emailOrsubject_arr = res.attendees[0].emailAddress.name.split('&');
                    if (emailOrsubject_arr.length === 2) {
                      var email_object = {
                        "Message": {
                          "Subject": emailOrsubject_arr[0],
                          "Body": {
                            "ContentType": res.body.contentType,
                            "Content": res.body.content,
                            "Content": '<div style="background-color: #e3e3e3;width: 100%;margin: 0;padding: 70px 0 70px 0;"><table style="border-collapse: collapse; margin: auto; background-color: #fafafa; border-radius: 6px 6px 0 0!important; width: 100%; max-width: 550px;"><tbody><tr><td style="font-size: 15px; padding: 10px; color: #500050; font-weight: 500;"><span>' + res.body.content + '</span></td></tr> <tr><td><table style="width: 100%; background: #fff;"><tbody><tr><td><table style="border-collapse: collapse; width: 100%;"><tbody><tr><th style="padding: 10px; border-bottom: 1px solid #ccc; text-align: left;">When:</th><td style="padding: 10px; border-bottom: 1px solid #ccc; text-align: left;">' + starttim + '&nbsp;&nbsp;to&nbsp;&nbsp;' + endtim + '</td></tr></tbody></table></td></tr></tbody></table></td></tr></tbody></table></td></tr><tr><td style="background: #243e68; color: #fff; padding: 10px;"><table style="width: 100%; text-align: center; border-top: 1px solid #e2e2e2; background: #243e68; border-radius: 0px 0px 6px 6px; max-width: 550px; margin: auto; color: #fff; padding: 1rem;"><tbody><tr><td style="text-align: center;"><span>©2022 Calender</span></td></tr></tbody></table></td></tr></tbody></table></div>'
                          },
                          "ToRecipients": [
                            {
                              "EmailAddress": {
                                "Address": emailOrsubject_arr[1],
                              }
                            }
                          ]
                        },
                        "SaveToSentItems": "true"
                      }
                      var token = localStorage.getItem('GraphToken');
                      const headers = {
                        "Authorization": `Bearer ${token}`,
                        'Content-type': 'application/json'
                      };
                      if (emailOrsubject_arr[1] != 'undefind' || emailOrsubject_arr[1] != '') {
                        axios.post(`https://graph.microsoft.com/v1.0/me/sendmail`, email_object, { headers })
                          .then((response) => {
                            return response.data
                          }, (error) => {
                            console.log(error);
                          })
                      }
                    }
                  });
                }
              })
              return data_list;
            },
            error => {
              console.error(error);
              this.apiCallFailed = true;
            }
          );
        },
        error => {
          console.error(error);
          this.apiCallFailed = true;
        }
      );
    }
  }

  //all id search data here..

//all eznum data here....
async AllEznum(){
  var user = this.getUser();
  if (user == null) {
    var userid = localStorage.getItem('userid')
    return axios.post('/api/eznum-get', { user: userid })
      .then((response) => {
        var data_array = [];
        data_array = response.data.message;
        var item = [];
        for (let i = 0; i < data_array.length; i++) {
          const element = data_array[i].id;
          // console.log(element === undefined)
          if (element === undefined) {
            var dateUTC = new Date(value.starttime);
            var dateUTC = dateUTC.getTime()
            var dateIST = new Date(dateUTC);
            dateIST.setHours(dateIST.getHours()+5 );
            dateIST.setMinutes(dateIST.getMinutes()+30 );
            var dateUTCend = new Date(value.endtime);
            var dateUTCend = dateUTCend.getTime()
            var dateISTend = new Date(dateUTCend);
            dateISTend.setHours(dateISTend.getHours()+5);
            dateISTend.setMinutes(dateISTend.getMinutes()+30);
            arr = {
              id:data_array[i].id,
              title: data_array[i].title,
              startCalendar: data_array[i].startCalendar,
              endCalendar: data_array[i].endCalendar,
              // starttime: data_array[i].starttime,
              // endtime: data_array[i].endtime,
              areadescription: data_array[i].areadescription,
              userid: localStorage.getItem('userid')
            }
          }
          else {
         var arr = {
              id:data_array[i].id,
              title: data_array[i].title,
              startCalendar: data_array[i].startCalendar,
              endCalendar: data_array[i].endCalendar,
              // starttime: data_array[i].starttime,
              // endtime: data_array[i].endtime,
              areadescription: data_array[i].areadescription,
              userid: localStorage.getItem('userid')
            }
          }
          item.push(arr);
          // console.log(item)
        }
        
        return item;
       
      },
        (error) => {
          console.error(error)
        })
  }else {
    return this.getGraphToken().then(
      token => {
        localStorage.setItem('GraphToken', token);
        return this.getGraphUserInfo(token).then(
          data => {
            var data_list = [];
            for (var i = 0; i < data.value.length; i++) {
              var arr = {
                id:data_list[i].id,
                title: data_list[i].title,
                startCalendar: data_list[i].startCalendar,
                endCalendar: data_list[i].endCalendar,
                // starttime: data_list[i].starttime,
                // endtime: data_list[i].endtime,
                areadescription: data_list[i].areadescription,
              }
              data_list.push(arr);
          //  console.log(data_list)
           }                     
            data.value.map(res => {
              if (res.attendees.length > 0) {
                var dateTime_arr = res.start.dateTime.split("T");
                var date_arr = dateTime_arr[0].split('-');
                var time_arrplusdot = dateTime_arr[1].split('.');
                var time_arr = time_arrplusdot[0].split(':');
                const rule = new schedule.RecurrenceRule();
                rule.hour = parseInt(time_arr[0]);
                rule.minute = parseInt((time_arr[1].substr(1, 1)) + 15);
                rule.second = parseInt(time_arr[2].substr(1, 1));
                rule.date = parseInt(date_arr[2]);
                rule.month = parseInt(((date_arr[1].substr(1, 1)) - 1));
                rule.year = parseInt(date_arr[0]);
                const job = schedule.scheduleJob(rule, function () {
                  var emailOrsubject_arr = res.attendees[0].emailAddress.name.split('&');
                  if (emailOrsubject_arr.length === 2) {
                    var email_object = {
                      "Message": {
                        "Subject": emailOrsubject_arr[0],
                        "Body": {
                          "ContentType": res.body.contentType,
                          "Content": res.body.content,
                          "Content": '<div style="background-color: #e3e3e3;width: 100%;margin: 0;padding: 70px 0 70px 0;"><table style="border-collapse: collapse; margin: auto; background-color: #fafafa; border-radius: 6px 6px 0 0!important; width: 100%; max-width: 550px;"><tbody><tr><td style="font-size: 15px; padding: 10px; color: #500050; font-weight: 500;"><span>' + res.body.content + '</span></td></tr> <tr><td><table style="width: 100%; background: #fff;"><tbody><tr><td><table style="border-collapse: collapse; width: 100%;"><tbody><tr><th style="padding: 10px; border-bottom: 1px solid #ccc; text-align: left;">When:</th><td style="padding: 10px; border-bottom: 1px solid #ccc; text-align: left;">' + starttim + '&nbsp;&nbsp;to&nbsp;&nbsp;' + endtim + '</td></tr></tbody></table></td></tr></tbody></table></td></tr></tbody></table></td></tr><tr><td style="background: #243e68; color: #fff; padding: 10px;"><table style="width: 100%; text-align: center; border-top: 1px solid #e2e2e2; background: #243e68; border-radius: 0px 0px 6px 6px; max-width: 550px; margin: auto; color: #fff; padding: 1rem;"><tbody><tr><td style="text-align: center;"><span>©2022 Calender</span></td></tr></tbody></table></td></tr></tbody></table></div>'
                        },
                        "ToRecipients": [
                          {
                            "EmailAddress": {
                              "Address": emailOrsubject_arr[1],
                            }
                          }
                        ]
                      },
                      "SaveToSentItems": "true"
                    }
                    var token = localStorage.getItem('GraphToken');
                    const headers = {
                      "Authorization": `Bearer ${token}`,
                      'Content-type': 'application/json'
                    };
                    if (emailOrsubject_arr[1] != 'undefind' || emailOrsubject_arr[1] != '') {
                      axios.post(`https://graph.microsoft.com/v1.0/me/sendmail`, email_object, { headers })
                        .then((response) => {
                          return response.data
                        }, (error) => {
                          console.log(error);
                        })
                    }
                  }
                });
              }
            })
            return data_list;
          },
          error => {
            console.error(error);
            this.apiCallFailed = true;
          }
        );
      },
      error => {
        console.error(error);
        this.apiCallFailed = true;
      }
    );
  }
}


//all eznum data here


//all entity trak data here...
async AllEntitytrak(){
  var user = this.getUser();
  if (user == null) {
    var userid = localStorage.getItem('userid')
    return axios.post('/api/entitytrak-data', { user: userid })
      .then((response) => {
        var data_array = [];
        data_array = response.data.message;
        var item = [];
        for (let i = 0; i < data_array.length; i++) {
          const element = data_array[i].id;
          // console.log(element === undefined)
          if (element === undefined) {
            var dateUTC = new Date(value.starttime);
            var dateUTC = dateUTC.getTime()
            var dateIST = new Date(dateUTC);
            dateIST.setHours(dateIST.getHours()+5 );
            dateIST.setMinutes(dateIST.getMinutes()+30 );
            var dateUTCend = new Date(value.endtime);
            var dateUTCend = dateUTCend.getTime()
            var dateISTend = new Date(dateUTCend);
            dateISTend.setHours(dateISTend.getHours()+5);
            dateISTend.setMinutes(dateISTend.getMinutes()+30);
            arr = {
              id:data_array[i].id,
              title: data_array[i].title,
              startCalendar: data_array[i].startCalendar,
              endCalendar: data_array[i].endCalendar,
              // starttime: data_array[i].starttime,
              // endtime: data_array[i].endtime,
              areadescription: data_array[i].areadescription,
              userid: localStorage.getItem('userid')
            }
          }
          else {
         var arr = {
              id:data_array[i].id,
              title: data_array[i].title,
              startCalendar: data_array[i].startCalendar,
              endCalendar: data_array[i].endCalendar,
              // starttime: data_array[i].starttime,
              // endtime: data_array[i].endtime,
              areadescription: data_array[i].areadescription,
              userid: localStorage.getItem('userid')
            }
          }
          item.push(arr);
          // console.log(item)
        }
        
        return item;
       
      },
        (error) => {
          console.error(error)
        })
  }else {
    return this.getGraphToken().then(
      token => {
        localStorage.setItem('GraphToken', token);
        return this.getGraphUserInfo(token).then(
          data => {
            var data_list = [];
            for (var i = 0; i < data.value.length; i++) {
              var arr = {
                id:data_list[i].id,
                title: data_list[i].title,
                startCalendar: data_list[i].startCalendar,
                endCalendar: data_list[i].endCalendar,
                // starttime: data_list[i].starttime,
                // endtime: data_list[i].endtime,
                areadescription: data_list[i].areadescription,
              }
              data_list.push(arr);
          //  console.log(data_list)
           }                     
            data.value.map(res => {
              if (res.attendees.length > 0) {
                var dateTime_arr = res.start.dateTime.split("T");
                var date_arr = dateTime_arr[0].split('-');
                var time_arrplusdot = dateTime_arr[1].split('.');
                var time_arr = time_arrplusdot[0].split(':');
                const rule = new schedule.RecurrenceRule();
                rule.hour = parseInt(time_arr[0]);
                rule.minute = parseInt((time_arr[1].substr(1, 1)) + 15);
                rule.second = parseInt(time_arr[2].substr(1, 1));
                rule.date = parseInt(date_arr[2]);
                rule.month = parseInt(((date_arr[1].substr(1, 1)) - 1));
                rule.year = parseInt(date_arr[0]);
                const job = schedule.scheduleJob(rule, function () {
                  var emailOrsubject_arr = res.attendees[0].emailAddress.name.split('&');
                  if (emailOrsubject_arr.length === 2) {
                    var email_object = {
                      "Message": {
                        "Subject": emailOrsubject_arr[0],
                        "Body": {
                          "ContentType": res.body.contentType,
                          "Content": res.body.content,
                          "Content": '<div style="background-color: #e3e3e3;width: 100%;margin: 0;padding: 70px 0 70px 0;"><table style="border-collapse: collapse; margin: auto; background-color: #fafafa; border-radius: 6px 6px 0 0!important; width: 100%; max-width: 550px;"><tbody><tr><td style="font-size: 15px; padding: 10px; color: #500050; font-weight: 500;"><span>' + res.body.content + '</span></td></tr> <tr><td><table style="width: 100%; background: #fff;"><tbody><tr><td><table style="border-collapse: collapse; width: 100%;"><tbody><tr><th style="padding: 10px; border-bottom: 1px solid #ccc; text-align: left;">When:</th><td style="padding: 10px; border-bottom: 1px solid #ccc; text-align: left;">' + starttim + '&nbsp;&nbsp;to&nbsp;&nbsp;' + endtim + '</td></tr></tbody></table></td></tr></tbody></table></td></tr></tbody></table></td></tr><tr><td style="background: #243e68; color: #fff; padding: 10px;"><table style="width: 100%; text-align: center; border-top: 1px solid #e2e2e2; background: #243e68; border-radius: 0px 0px 6px 6px; max-width: 550px; margin: auto; color: #fff; padding: 1rem;"><tbody><tr><td style="text-align: center;"><span>©2022 Calender</span></td></tr></tbody></table></td></tr></tbody></table></div>'
                        },
                        "ToRecipients": [
                          {
                            "EmailAddress": {
                              "Address": emailOrsubject_arr[1],
                            }
                          }
                        ]
                      },
                      "SaveToSentItems": "true"
                    }
                    var token = localStorage.getItem('GraphToken');
                    const headers = {
                      "Authorization": `Bearer ${token}`,
                      'Content-type': 'application/json'
                    };
                    if (emailOrsubject_arr[1] != 'undefind' || emailOrsubject_arr[1] != '') {
                      axios.post(`https://graph.microsoft.com/v1.0/me/sendmail`, email_object, { headers })
                        .then((response) => {
                          return response.data
                        }, (error) => {
                          console.log(error);
                        })
                    }
                  }
                });
              }
            })
            return data_list;
          },
          error => {
            console.error(error);
            this.apiCallFailed = true;
          }
        );
      },
      error => {
        console.error(error);
        this.apiCallFailed = true;
      }
    );
  }
}

//all entity trak data end here..

  //all clastrak data here...
  async AllClastrak(){
  // console.log("AllClastrak")
    var user = this.getUser();
    if (user == null) {
      var userid = localStorage.getItem('userid')
      return axios.post('/api/clastrak-data', { user: userid })
        .then((response) => {
          var data_array = [];
          data_array = response.data.message;
          var item = [];
          for (let i = 0; i < data_array.length; i++) {
            const element = data_array[i].id;
            // console.log(element === undefined)
            if (element === undefined) {
              var dateUTC = new Date(value.starttime);
              var dateUTC = dateUTC.getTime()
              var dateIST = new Date(dateUTC);
              dateIST.setHours(dateIST.getHours()+5 );
              dateIST.setMinutes(dateIST.getMinutes()+30 );
              var dateUTCend = new Date(value.endtime);
              var dateUTCend = dateUTCend.getTime()
              var dateISTend = new Date(dateUTCend);
              dateISTend.setHours(dateISTend.getHours()+5);
              dateISTend.setMinutes(dateISTend.getMinutes()+30);
              arr = {
                id:data_array[i].id,
                title: data_array[i].title,
                startCalendar: data_array[i].startCalendar,
                endCalendar: data_array[i].endCalendar,
                starttime: data_array[i].starttime,
                endtime: data_array[i].endtime,
                areadescription: data_array[i].areadescription,
                userid: localStorage.getItem('userid')
              }
            }
            else {
           var arr = {
                id:data_array[i].id,
                title: data_array[i].title,
                startCalendar: data_array[i].startCalendar,
                endCalendar: data_array[i].endCalendar,
                starttime: data_array[i].starttime,
                endtime: data_array[i].endtime,
                areadescription: data_array[i].areadescription,
                userid: localStorage.getItem('userid')
              }
            }
            item.push(arr);
            // console.log(item)
          }
        
          return item;         
        },
          (error) => {
            console.error(error)
          })
    }else {
      return this.getGraphToken().then(
        token => {
          localStorage.setItem('GraphToken', token);
          return this.getGraphUserInfo(token).then(
            data => {
              var data_list = [];
              for (var i = 0; i < data.value.length; i++) {
                var arr = {
                  id:data_list[i].id,
                  title: data_list[i].title,
                  startCalendar: data_list[i].startCalendar,
                  endCalendar: data_list[i].endCalendar,
                  starttime: data_list[i].starttime,
                  endtime: data_list[i].endtime,
                  areadescription: data_list[i].areadescription,
                }
                data_list.push(arr);
             }                     
              data.value.map(res => {
                if (res.attendees.length > 0) {
                  var dateTime_arr = res.start.dateTime.split("T");
                  var date_arr = dateTime_arr[0].split('-');
                  var time_arrplusdot = dateTime_arr[1].split('.');
                  var time_arr = time_arrplusdot[0].split(':');
                  const rule = new schedule.RecurrenceRule();
                  rule.hour = parseInt(time_arr[0]);
                  rule.minute = parseInt((time_arr[1].substr(1, 1)) + 15);
                  rule.second = parseInt(time_arr[2].substr(1, 1));
                  rule.date = parseInt(date_arr[2]);
                  rule.month = parseInt(((date_arr[1].substr(1, 1)) - 1));
                  rule.year = parseInt(date_arr[0]);
                  const job = schedule.scheduleJob(rule, function () {
                    var emailOrsubject_arr = res.attendees[0].emailAddress.name.split('&');
                    if (emailOrsubject_arr.length === 2) {
                      var email_object = {
                        "Message": {
                          "Subject": emailOrsubject_arr[0],
                          "Body": {
                            "ContentType": res.body.contentType,
                            "Content": res.body.content,
                            "Content": '<div style="background-color:#e3e3e3;width: 100%;margin: 0;padding: 70px 0 70px 0;"><table style="border-collapse: collapse; margin: auto; background-color: #fafafa; border-radius: 6px 6px 0 0!important; width: 100%; max-width: 550px;"><tbody><tr><td style="font-size: 15px; padding: 10px; color: #500050; font-weight: 500;"><span>' + res.body.content + '</span></td></tr> <tr><td><table style="width: 100%; background: #fff;"><tbody><tr><td><table style="border-collapse: collapse; width: 100%;"><tbody><tr><th style="padding: 10px; border-bottom: 1px solid #ccc; text-align: left;">When:</th><td style="padding: 10px; border-bottom: 1px solid #ccc; text-align: left;">' + starttim + '&nbsp;&nbsp;to&nbsp;&nbsp;' + endtim + '</td></tr></tbody></table></td></tr></tbody></table></td></tr></tbody></table></td></tr><tr><td style="background: #243e68; color: #fff; padding: 10px;"><table style="width: 100%; text-align: center; border-top: 1px solid #e2e2e2; background: #243e68; border-radius: 0px 0px 6px 6px; max-width: 550px; margin: auto; color: #fff; padding: 1rem;"><tbody><tr><td style="text-align: center;"><span>©2022 Calender</span></td></tr></tbody></table></td></tr></tbody></table></div>'
                          },
                          "ToRecipients": [
                            {
                              "EmailAddress": {
                                "Address": emailOrsubject_arr[1],
                              }
                            }
                          ]
                        },
                        "SaveToSentItems": "true"
                      }
                      var token = localStorage.getItem('GraphToken');
                      const headers = {
                        "Authorization": `Bearer ${token}`,
                        'Content-type': 'application/json'
                      };
                      if (emailOrsubject_arr[1] != 'undefind' || emailOrsubject_arr[1] != '') {
                        axios.post(`https://graph.microsoft.com/v1.0/me/sendmail`, email_object, { headers })
                          .then((response) => {
                            return response.data
                          }, (error) => {
                            console.log(error);
                          })
                      }
                    }
                  });
                }
              })        
              return data_list;
            },
            error => {
              console.error(error);
              this.apiCallFailed = true;
            }
          );
        },
        error => {
          console.error(error);
          this.apiCallFailed = true;
        }
      );
    }
  }
  // all clastrak data end here...

  //alldata get here...
  async Alldataget() {
    var user = this.getUser();
    if (user == null) {
      var userid = localStorage.getItem('userid')
      return axios.post('/api/get-events', { user: userid })
        .then((response) => {
          var data_array = [];
          data_array = response.data.message;
          var list = [];
          for (let i = 0; i < data_array.length; i++) {
            const element = data_array[i].allData.id;
            // console.log(element === undefined)
            if (element === undefined) {
              var dateUTC = new Date(data_array[i].allData.StartTime);
              var dateUTC = dateUTC.getTime()
              var dateIST = new Date(dateUTC);
              dateIST.setHours(dateIST.getHours() + 5);
              dateIST.setMinutes(dateIST.getMinutes() + 30);
              var dateUTCend = new Date(data_array[i].allData.EndTime);
              var dateUTCend = dateUTCend.getTime()
              var dateISTend = new Date(dateUTCend);
              dateISTend.setHours(dateISTend.getHours() + 5);
              dateISTend.setMinutes(dateISTend.getMinutes() + 30);
              var arr = {
                Id: data_array[i].id,
                Subject: data_array[i].allData.Subject,
                email_subject: data_array[i].email_subject,
                email_body: data_array[i].email_body,
                email_id: data_array[i].email_to,
                StartTime: dateIST,                               
                location: data_array[i].Location,
                StartTimezone: 'India Standard Time',//data.value[i].start.timeZone,
                EndTimezone: 'India Standard Time',///data.value[i].end.timeZone,
                EndTime: dateISTend,//new Date (data.value[i].end.dateTime).toString(
                CategoryColor: '#1aaa55',
              }
            }
            else {
              var dateUTC = new Date(data_array[i].allData.start.dateTime);
              var dateUTC = dateUTC.getTime()
              var dateIST = new Date(dateUTC);
              dateIST.setHours(dateIST.getHours() + 5);
              dateIST.setMinutes(dateIST.getMinutes() +30);
              var dateUTCend = new Date(data_array[i].allData.end.dateTime);
              var dateUTCend = dateUTCend.getTime()
              var dateISTend = new Date(dateUTCend);
              dateISTend.setHours(dateISTend.getHours() + 5);
              dateISTend.setMinutes(dateISTend.getMinutes() +30);
              var arr = {
                Id: data_array[i].id,
                Subject: data_array[i].allData.subject,
                email_subject: data_array[i].email_subject,
                email_body: data_array[i].email_body,
                email_id: data_array[i].email_to,
                StartTime: dateIST,
                id:data_array[i].id,                       
                StartTimezone: 'India Standard Time',//data.value[i].start.timeZone,
                EndTimezone: 'India Standard Time',///data.value[i].end.timeZone,
                EndTime: dateISTend,//new Date (data.value[i].end.dateTime).toString(),
                IsAllDay: data_array[i].allData.isAllDay,
                RecurrenceRule: data_array[i].allData.recurrence,
                location: data_array[i].allData.location.displayName,
                Description: data_array[i].allData.bodyPreview,
                CategoryColor: '#1aaa55',
              }
            }
            list.push(arr);
          }
        
          return list;
        },
          (error) => {
            console.error(error)
          })
    } 
    else {
      return this.getGraphToken().then(
        token => {
          localStorage.setItem('GraphToken', token);
          return this.getGraphUserInfo(token).then(
            data => {
              var data_list = [];
              for (var i = 0; i < data.value.length; i++) {
                var dateUTC = new Date(data.value[i].start.dateTime);
                var dateUTC = dateUTC.getTime()
                var dateIST = new Date(dateUTC);
                dateIST.setHours(dateIST.getHours() + 11);
                dateIST.setMinutes(dateIST.getMinutes());
                var dateUTCend = new Date(data.value[i].end.dateTime);
                var dateUTCend = dateUTCend.getTime()
                var dateISTend = new Date(dateUTCend);
                dateISTend.setHours(dateISTend.getHours() + 11);
                dateISTend.setMinutes(dateISTend.getMinutes());
                var arr = {
                  Id: data_list[i].Id,
                  Subject: data_list[i].subject,
                  StartTime: dateIST,
                  StartTimezone: 'India Standard Time',//data_list[i].start.timeZone,
                  EndTimezone: 'India Standard Time',///data_list[i].end.timeZone,
                  EndTime: dateISTend,//new Date (data_list[i].end.dateTime).toString(),
                  IsAllDay: data_list[i].isAllDay,
                  RecurrenceRule: data_list[i].recurrence,
                  location: data_list[i].location,
                  Description: data_list[i].Description,
                  email_subject: data_list[i].email_subject,
                  email_body: data_list[i].email_body,
                  email_id: data_list[i].email_to,
                  CategoryColor: '#1aaa55',
                }
                data_list.push(arr);
                var text = new Date(data_list[i].start.dateTime);
                var text1 = new Date(data_list[i].end.dateTime);
                var starttim = ((text.toLocaleString('default', { month: 'short' })) + "-" + (text.getUTCDate()) + "-" + (text.getUTCFullYear()) + " " + text.toLocaleTimeString());
                var endtim = ((text1.toLocaleString('default', { month: 'short' })) + "-" + (text1.getUTCDate()) + "-" + (text1.getUTCFullYear()) + " " + text1.toLocaleTimeString());
              }
              data.value.map(res => {
                if (res.attendees.length > 0) {
                  var dateTime_arr = res.start.dateTime.split("T");
                  var date_arr = dateTime_arr[0].split('-');
                  var time_arrplusdot = dateTime_arr[1].split('.');
                  var time_arr = time_arrplusdot[0].split(':');
                  const rule = new schedule.RecurrenceRule();
                  rule.hour = parseInt(time_arr[0]);
                  rule.minute = parseInt((time_arr[1].substr(1, 1)) + 15);
                  rule.second = parseInt(time_arr[2].substr(1, 1));
                  rule.date = parseInt(date_arr[2]);
                  rule.month = parseInt(((date_arr[1].substr(1, 1)) - 1));
                  rule.year = parseInt(date_arr[0]);
                  const job = schedule.scheduleJob(rule, function () {
                    var emailOrsubject_arr = res.attendees[0].emailAddress.name.split('&');
                    if (emailOrsubject_arr.length === 2) {
                      var email_object = {
                        "Message": {
                          "Subject": emailOrsubject_arr[0],
                          "Body": {
                            "ContentType": res.body.contentType,
                            "Content": res.body.content,
                            "Content": '<div style="background-color: #e3e3e3;width: 100%;margin: 0;padding: 70px 0 70px 0;"><table style="border-collapse: collapse; margin: auto; background-color: #fafafa; border-radius: 6px 6px 0 0!important; width: 100%; max-width: 550px;"><tbody><tr><td style="font-size: 15px; padding: 10px; color: #500050; font-weight: 500;"><span>' + res.body.content + '</span></td></tr> <tr><td><table style="width: 100%; background: #fff;"><tbody><tr><td><table style="border-collapse: collapse; width: 100%;"><tbody><tr><th style="padding: 10px; border-bottom: 1px solid #ccc; text-align: left;">When:</th><td style="padding: 10px; border-bottom: 1px solid #ccc; text-align: left;">' + starttim + '&nbsp;&nbsp;to&nbsp;&nbsp;' + endtim + '</td></tr></tbody></table></td></tr></tbody></table></td></tr></tbody></table></td></tr><tr><td style="background: #243e68; color: #fff; padding: 10px;"><table style="width: 100%; text-align: center; border-top: 1px solid #e2e2e2; background: #243e68; border-radius: 0px 0px 6px 6px; max-width: 550px; margin: auto; color: #fff; padding: 1rem;"><tbody><tr><td style="text-align: center;"><span>©2022 Calender</span></td></tr></tbody></table></td></tr></tbody></table></div>'
                          },
                          "ToRecipients": [
                            {
                              "EmailAddress": {
                                "Address": emailOrsubject_arr[1],
                              }
                            }
                          ]
                        },
                        "SaveToSentItems": "true"
                      }
                      var token = localStorage.getItem('GraphToken');
                      const headers = {
                        "Authorization": `Bearer ${token}`,
                        'Content-type': 'application/json'
                      };
                      if (emailOrsubject_arr[1] != 'undefind' || emailOrsubject_arr[1] != '') {
                        axios.post(`https://graph.microsoft.com/v1.0/me/sendmail`, email_object, { headers })
                          .then((response) => {
                            return response.data
                          }, (error) => {
                            console.log(error);
                          })
                      }
                    }
                  });
                }
              })
              return data_list;
            },
            error => {
              console.error(error);
              this.apiCallFailed = true;
            }
          );
        },
        error => {
          console.error(error);
          this.apiCallFailed = true;
        }
      );
    }
  }
}
