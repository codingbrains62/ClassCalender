import Vue from 'vue'
import VueRouter from 'vue-router'
import Login from '../views/Login.vue'
import Dashboard from '../views/Dashboard.vue'
import Cipinfobox from '../views/Cipinfobox.vue'
import Userprofile from '../views/Userprofile'
import Adduser from '../views/Adduser'
import Edituser from '../views/Edituser'
import Forgotpassword from '../views/Forgotpassword.vue'
import Resetpassword from '../views/Resetpassword.vue'
import Placeorder from '../views/Placeorder.vue'
import Events from '../views/Events.vue'
import addevent from '../views/addevent.vue'
import editevent from '../views/editevent.vue'
import historylog from '../views/historylog.vue'
import errorlog from '../views/errorlog.vue'

Vue.use(VueRouter)

const routes = [
  {
    path: '/',
    name: 'Login',
    component: Login
  }, 
  {
    path: '/Dashboard',
    name: 'Dashboard',
    component: Dashboard
  },
  {
    path: '/cipinfobox',
    name: 'Cipinfobox',
    component: Cipinfobox
  },
  {
    path: '/Userprofile',
    name: 'Userprofile',
    component: Userprofile
  },
  {
    path: '/forgotpassword',
    name: 'Forgotpassword',
    component: Forgotpassword
  },
  {
    path: '/resetpassword',
    name: 'Resetpassword',
    component: Resetpassword
  },
  {
    path: '/adduser',
    name: 'Adduser',
    component: Adduser
  },
  {
    path: '/edituser',
    name: 'Edituser',
    component: Edituser
  },
  {
    path: '/placeorder',
    name: 'Placeorder',
    component: Placeorder
  },{
    path: '/events',
    name: 'Events',
    component: Events
  },
  {
    path: '/addevent',
    name: 'addevent',
    component: addevent
  },
  {
    path: '/editevent',
    name: 'editevent',
    component: editevent
  },
  {
    path: '/historylog',
    name: 'historylog',
    component: historylog
  },
  {
    path: '/errorlog',
    name: 'errorlog',
    component: errorlog
  }
  // {
  //   path: '/about',
  //   name: 'About',
  //   // route level code-splitting
  //   // this generates a separate chunk (about.[hash].js) for this route
  //   // which is lazy-loaded when the route is visited.
  //   component: () => import(/* webpackChunkName: "about" */ '../views/About.vue')
  // }
]

const router = new VueRouter({
  mode: 'history',
  base: process.env.BASE_URL,
  routes
})

export default router
