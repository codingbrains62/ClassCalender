<template>
  <div class="mainwrapper" v-on:click="closeMenu()">
     <cipnav/>
     <router-view/>
  </div>
</template>

<script>
// @ is an alias to /src
import cipnav from './components/cipnav.vue'

export default {
  components: {
    cipnav
  },
   methods: {
      closeMenu: function() {
        let row = document.querySelectorAll(".container .row");
      for (let i = 0; i < row.length; i++) {
        row[i].classList.remove("open_menu");
      }

     
    },

   

   },
}
</script>

