<template>
    <div class="usermain">
       <div class="row">
           <div class="col-md-6">
               
             <b-form @submit.prevent="add_user" id="form">
                   <div class="col-md-12">
                       
                        <b-card bg-variant="light">
                            <h2>User Profile</h2>
                            <div class="secbrder">
                            <b-form-group
                                label="User Name"
                                label-for="user-name"
                                label-cols-sm="2"
                                label-align-sm="right"
                            >
                                <b-form-input id="user-name" disabled v-model="username" type="text" required></b-form-input>
                            </b-form-group>
                            <b-form-group
                                label=" Full Name  "
                                label-cols-sm="2"
                                label-align-sm="right"
                               
                            >
                               <b-form-input id="full_name" disabled type="text" v-model="fullName" required ></b-form-input>
                            </b-form-group>

                            <b-form-group
                                label="Company"
                                label-for="user-company"
                                label-cols-sm="2"
                                label-align-sm="right"
                            >
                                <b-form-input id="user-company" disabled type="text" v-model="company" required></b-form-input>
                            </b-form-group>

                            <b-form-group
                                label="Email"
                                label-for="user-email"
                                label-cols-sm="2"
                                label-align-sm="right"
                            >
                                <b-form-input id="user-email" disabled v-model="email" type="email" required></b-form-input>
                            </b-form-group>
                            <b-form-group
                                label=" Alternate Email  "
                                label-cols-sm="2"
                                label-align-sm="right"
                              
                            >
                               <b-form-input id="alt_name_email" type="email"  v-model="alt_name_email" disabled></b-form-input>
                            </b-form-group>
                             <b-form-group
                                label="Phone "
                                label-cols-sm="2"
                                label-align-sm="right"
                                
                            >
                               <b-form-input id="phone" disabled type="number" v-model="phone" required></b-form-input>
                            </b-form-group>
                            <b-form-group
                                label=" Cell Phone "
                                label-cols-sm="2"
                                label-align-sm="right"
                                
                            >
                               <b-form-input id="cell_phone"  disabled type="number" v-model="cell_phone" ></b-form-input>
                            </b-form-group>

                            <b-form-group
                                label="Password"
                                label-for="user-password"
                                label-cols-sm="2"
                                label-align-sm="right"
                            >
                                <b-form-input id="user-password" disabled v-model="password" type="password" required></b-form-input>
                            </b-form-group>
                             <b-form-group
                                label="Address"
                                label-for="address"
                                label-cols-sm="2"
                                label-align-sm="right"
                            >
                                <b-form-textarea
                                      id="address"
                                      v-model="address"
                                      placeholder="Enter something..."
                                      rows="3"
                                      max-rows="6"
                                      disabled
                                      
                                ></b-form-textarea>
                            </b-form-group>

                            <b-form-group
                                label="Security role"
                                label-for="security-role"
                                label-cols-sm="2"
                                label-align-sm="right"
                            >
                                <select v-model="selected" class="form-control" disabled>
                                      <option v-for="option in options"  v-bind:value="option.value">
                                        {{ option.text }}
                                      </option>
                                </select>
                            </b-form-group>
                            <div class="clear"></div>
                            </div>
                        </b-card>
                   </div>
              </b-form>
           </div>
           <div class="col-md-6"> 
            <b-card bg-variant="light">
             <div class="row adduser">
                 <div class="col-sm-4">
                <h2>ABC Company users</h2>
             </div>
             <div class="col-sm-2">
                <a  href="JavaScript:void(0)" @click="adduser()"> <b-icon-plus-circle></b-icon-plus-circle>
                <span>Add user</span></a>
             </div>
             <div class="col-sm-2">
               <a href="JavaScript:void(0)" @click="edit()"> <b-icon-pencil></b-icon-pencil>
                <span>Edit user</span></a>
             </div>
             <div class="col-sm-2">
               <a href="JavaScript:void(0)" @click="disabled()"> <b-icon-person-x></b-icon-person-x>
                
                <span>Disable user</span></a>
             </div>
             <div class="col-sm-2">
                <a href="JavaScript:void(0)" @click="remove()"> <b-icon-x></b-icon-x>
                <span>Remove user</span> </a>
             </div>
             </div>
            <div class="secbrder">
                <div id="table">
                     <b-form-input v-model="keyword" placeholder="Search"></b-form-input>
                     <b-table id="my-table" hover  :items="items" :fields="fields" :tbody-tr-class="rowClass" @row-clicked="showdetails"  :per-page="perPage" :current-page="currentPage" small>
                         
                       <template v-slot:cell(Actions)="row">
                              <b-button v-b-tooltip.hover v-bind:title="row.item.isDisabled"  variant="outline-success" class="btn btn-sm m-2"> <b-icon icon="clipboard-check"></b-icon></b-button>
                             
                            
                            </template>
                     </b-table>
                     <b-pagination
                      v-model="currentPage"
                      :total-rows="rows"
                      :per-page="perPage"
                      aria-controls="my-table"
                    ></b-pagination>
                </div>
            </div>
         </b-card></div>
       </div>
    </div>
</template>
<script>

import axios from 'axios'
export default({
   /// el: '#table',
    data () {
        return {
             perPage: 10,
            currentPage: 1,
            username:'',
            email:'',
            password:'',
            company:'',
            address:'',
            phone:'',
            cell_phone:'',
            alt_name_email:'',
            fullName:'',
             selected: 'A',
            options: [
              { text: 'Organization  User', value: ' Organization s User' },    
              { text: 'Company User', value: ' Company s User' },
              { text: 'User', value: 'User' },
              { text: 'Guest', value: 'Guest' },
            ],
            keyword: '',
            dataArray: [],
            fields: [{ key: 'fullName', sortable: true },{ key: 'Actions', sortable: false }]
        }
    }, 
    mounted () {

            this.get_user()

    },
    computed: {
        items () {
            return  this.keyword
                ? this.dataArray.filter(item => item.fullName.toLowerCase().includes(this.keyword.toLowerCase()))
                : this.dataArray
            
        },
        rows() {
        return this.dataArray.length
      }
    },
    methods:{ 
    rowClass(item, type) {
        if (!item || type !== 'row') return
        if (item.status === 'awesome') return 'table-info'
      },
    async get_user(){
              axios.get('/api/view-user', {
               
            }).then((response) => {
                if(response.data.status_code == "200"){
                   
                   const lastSegment = localStorage.getItem('lastSegment');
                   if(lastSegment == 1){
                    
                        data=  response.data.message;
                         var userid=localStorage.getItem('edituser');
                       this.dataArray=data;
                        for (var i = 0; i < data.length; i++) {
                    
                          
                            if(data[i].id == userid)
                            {
                                this.showdetails(data[i])
                                  
                               
                            }
                        }

                        this.active();
                   }
                   else
                   {
                    
                    var data = response.data.message;
                    var newdata=[];
                    for (var k = 0; k < data.length; k++) {
                        if(data[k].isDisabled=== false)
                        {
                            var active="Yes";
                        }else if(data[k].isDisabled=== true){
                              var active="No";
                        }
                        
                        if(k == 0)
                        {
                            this.showdetails(data[k])
                               var newarray={
                                "id":data[k].id,                        
                                "fullName":data[k].fullName,
                                "isDisabled":data[k].isDisabled,    
                                "status": 'awesome'              
                                }
                            newdata.push(newarray);
                           
                        }else{
                            var newarray={
                                "id":data[k].id,                        
                                "fullName":data[k].fullName,
                                 "isDisabled":data[k].isDisabled,  
                                
                                }
                                 newdata.push(newarray);
                          }
                        }
                    this.dataArray=newdata;
               
                   }
                }
                else if(response.data.record.status_code==403){
                              this.$toast.error({message:response.data.record.message})
                                localStorage.clear();
                                location.replace("/");
                        }
            },(error) => {
                console.log(error);
            });
       
         
      },
      
     showdetails(data) {
             if(data.id)
             {
                localStorage.setItem('edituser',data.id)
                 axios.post('/api/view-profile',{id:data.id               
                    }).then((response) => {
                        if(response.data.record.status_code==200){
                            this.active();
                            this.username=response.data.record.message.username;
                            this.fullName=response.data.record.message.fullName;
                            this.phone=response.data.record.message.phone;
                            this.cell_phone=response.data.record.message.cellPhone;
                            this.address=response.data.record.message.address;
                            this.company=response.data.record.message.company_name;
                            this.email=response.data.record.message.emailAddress;
                            this.alt_name_email=response.data.record.message.alternateEmailAddress;
                            this.password=response.data.record.message.password;
                            this.selected=response.data.record.message.SecurityLevel;
                            localStorage.setItem('lastSegment',0)
                        }else if(response.data.record.status_code==500){
                              this.$toast.success({message:response.data.record.message})
                                
                        }
                        else if(response.data.record.status_code==403){
                              this.$toast.error({message:response.data.record.message})
                                localStorage.clear();
                                location.replace("/");
                        }
                        ///console.log(response);
                    },(error) => {
                        console.log(error);
                    });
             }
        },
        edit(){
            var editid=localStorage.getItem('edituser');
            if(editid){

                location.replace("/edituser");
                localStorage.setItem('lastSegment',1)
            }
            else
            {
                 this.$toast.error({message:"Please select user "})
            }

        },adduser(){
                location.replace("/adduser");
                localStorage.setItem('lastSegment',0)
        },
        remove()
        {
            var removeid=localStorage.getItem('edituser');
            if(removeid){

                 if(confirm("Are You Sure Remove This User "))
                    {
                       axios.post('/api/remove-user',{id:removeid               
                             }).then((response) => {
                        if(response.data.record.status_code==200){
                             this.$toast.success({message:response.data.record.message});
                        localStorage.setItem('lastSegment',0)
                             this.get_user();
                        }else if(response.data.record.status_code==202){
                              this.$toast.error({message:response.data.record.message})
                                
                        }
                        else if(response.data.record.status_code==500){
                              this.$toast.error({message:response.data.record.message})
                                
                        }
                        else if(response.data.record.status_code==403){
                              this.$toast.error({message:response.data.record.message})
                                localStorage.clear();
                                location.replace("/");
                        }
                        
                        ///console.log(response);
                    },(error) => {
                        console.log(error);
                    });
                    }
            }
            else
            {
                 this.$toast.error({message:"Please select user "})
            } 
        },disabled(){
             var disable_id=localStorage.getItem('edituser');
            if(disable_id){

                         localStorage.setItem('lastSegment',1)
                       axios.post('/api/disable-user',{id:disable_id               
                             }).then((response) => {
                        if(response.data.record.status_code==200){
                             this.$toast.success({message:response.data.record.message});
                        //localStorage.setItem('lastSegment',0)
                             this.get_user();
                        }else if(response.data.record.status_code==202){
                              this.$toast.error({message:response.data.record.message})
                                
                        }
                        else if(response.data.record.status_code==500){
                              this.$toast.error({message:response.data.record.message})
                                
                        }
                        else if(response.data.record.status_code==403){
                              this.$toast.error({message:response.data.record.message})
                                localStorage.clear();
                                location.replace("/");
                        }
                        
                        ///console.log(response);
                    },(error) => {
                        console.log(error);
                    });
                   
            }
            else
            {
                 this.$toast.error({message:"Please select user "})
            }
        }
        ,
        active(){
            var data = this.dataArray;
            var userid=localStorage.getItem('edituser');
            
               
                    var newdata=[];
                    for (var i = 0; i < data.length; i++) {
                            var newarray='';
                        if(data[i].isDisabled==false)
                        {
                            var active="Yes";
                        }else if(data[i].isDisabled==true){
                            var active="No";
                        }
            
                    if(data[i].id == userid)
                    {
                            newarray={
                            "id":data[i].id,                        
                            "fullName":data[i].fullName,
                            "isDisabled": data[i].isDisabled,                          
                            "status": 'awesome'                       

                            }
                        newdata.push(newarray);
                       
                    }else{
                        newarray={
                            "id":data[i].id,                        
                            "fullName":data[i].fullName,
                            "isDisabled":data[i].isDisabled,                         
                                                  
                            
                                                  

                            }
                             newdata.push(newarray);
                      }
                    }
                    this.dataArray=newdata;
                    
                
        }
    }
})
</script>