<template>
  <div class="container-fluid">
    <div class="row place_order events_view text-center">
      <div class="container">
        <div class="row">
          <div class="col-md-12">
            <h2>Events List</h2>
          </div>
        </div>
      </div>
    </div>
    <div class="row events_list_table">
      <div class="container">
        <div class="row">
          <div class="col-md-12">
            <div class="usermain">
              <div class="row">
                <div class="col-md-6">
                  <b-form @submit.prevent="add_user" id="form">
                    <div class="col-md-12">
                      <b-card bg-variant="light">
                        <h2>Event Details</h2>
                        <div class="secbrder">
                          <b-form-group
                            label="User Name"
                            label-for="user-name"
                            label-cols-sm="2"
                            label-align-sm="right"
                          >
                            <b-form-input
                              id="user-name"
                              disabled
                              v-model="username"
                              type="text"
                              required
                            ></b-form-input>
                          </b-form-group>
                          <b-form-group
                            label=" Full Name  "
                            label-cols-sm="2"
                            label-align-sm="right"
                          >
                            <b-form-input
                              id="full_name"
                              disabled
                              type="text"
                              v-model="fullName"
                              required
                            ></b-form-input>
                          </b-form-group>

                          <b-form-group
                            label="Company"
                            label-for="user-company"
                            label-cols-sm="2"
                            label-align-sm="right"
                          >
                            <b-form-input
                              id="user-company"
                              disabled
                              type="text"
                              v-model="company"
                              required
                            ></b-form-input>
                          </b-form-group>

                          <b-form-group
                            label="Email"
                            label-for="user-email"
                            label-cols-sm="2"
                            label-align-sm="right"
                          >
                            <b-form-input
                              id="user-email"
                              disabled
                              v-model="email"
                              type="email"
                              required
                            ></b-form-input>
                          </b-form-group>
                          <b-form-group
                            label=" Alternate Email  "
                            label-cols-sm="2"
                            label-align-sm="right"
                          >
                            <b-form-input
                              id="alt_name_email"
                              type="email"
                              v-model="alt_name_email"
                              disabled
                            ></b-form-input>
                          </b-form-group>
                          <b-form-group
                            label="Phone "
                            label-cols-sm="2"
                            label-align-sm="right"
                          >
                            <b-form-input
                              id="phone"
                              disabled
                              type="number"
                              v-model="phone"
                              required
                            ></b-form-input>
                          </b-form-group>
                          <b-form-group
                            label=" Cell Phone "
                            label-cols-sm="2"
                            label-align-sm="right"
                          >
                            <b-form-input
                              id="cell_phone"
                              disabled
                              type="number"
                              v-model="cell_phone"
                            ></b-form-input>
                          </b-form-group>

                          <b-form-group
                            label="Password"
                            label-for="user-password"
                            label-cols-sm="2"
                            label-align-sm="right"
                          >
                            <b-form-input
                              id="user-password"
                              disabled
                              v-model="password"
                              type="password"
                              required
                            ></b-form-input>
                          </b-form-group>
                          <b-form-group
                            label="Address"
                            label-for="address"
                            label-cols-sm="2"
                            label-align-sm="right"
                          >
                            <b-form-textarea
                              id="address"
                              v-model="address"
                              placeholder="Enter something..."
                              rows="3"
                              max-rows="6"
                              disabled
                            ></b-form-textarea>
                          </b-form-group>

                          <b-form-group
                            label="Security role"
                            label-for="security-role"
                            label-cols-sm="2"
                            label-align-sm="right"
                          >
                            <select
                              v-model="selected"
                              class="form-control"
                              disabled
                            >
                              <option
                                v-for="option in options"
                                v-bind:value="option.value"
                              >
                                {{ option.text }}
                              </option>
                            </select>
                          </b-form-group>
                          <div class="clear"></div>
                        </div>
                      </b-card>
                    </div>
                  </b-form>
                </div>
                <div class="col-md-6">
                  <b-card bg-variant="light">
                    <div class="row adduser">
                      <div class="col-sm-4">
                        <h2>ABC Company users</h2>
                      </div>
                      <div class="col-sm-2">
                        <a href="JavaScript:void(0)" @click="adduser()">
                          <b-icon-plus-circle></b-icon-plus-circle>
                          <span>Add Event</span></a
                        >
                      </div>
                      <div class="col-sm-2">
                        <a href="JavaScript:void(0)" @click="edit()">
                          <b-icon-pencil></b-icon-pencil>
                          <span>Edit Event</span></a
                        >
                      </div>
                      <div class="col-sm-2">
                        <a href="JavaScript:void(0)" @click="disabled()">
                          <b-icon-person-x></b-icon-person-x>

                          <span>Disable Event</span></a
                        >
                      </div>
                      <div class="col-sm-2">
                        <a href="JavaScript:void(0)" @click="remove()">
                          <b-icon-x></b-icon-x> <span>Remove Event</span>
                        </a>
                      </div>
                    </div>
                    <div class="secbrder">
                      <div id="table">
                        <b-form-input
                          v-model="keyword"
                          placeholder="Search"
                        ></b-form-input>
                        <b-table
                          id="my-table"
                          hover
                          :items="items"
                          :fields="fields"
                          :tbody-tr-class="rowClass"
                          @row-clicked="showdetails"
                          :per-page="perPage"
                          :current-page="currentPage"
                          small
                        >
                        </b-table>
                        <b-pagination
                          v-model="currentPage"
                          :total-rows="rows"
                          :per-page="perPage"
                          aria-controls="my-table"
                        ></b-pagination>
                      </div>
                    </div>
                  </b-card>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: "Events",
  
};
</script>
