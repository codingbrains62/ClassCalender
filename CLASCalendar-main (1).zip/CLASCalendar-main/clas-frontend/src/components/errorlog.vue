<template>
    <div class="container-fluid">
      <div class="row heading_bg">
          <div class="container">
            <div class="row">
              <div class="col-md-12 text-center">
                  <h2>Error Log</h2>
              </div>
            </div>
          </div>
      </div>
      <div class="row history_log_content">
        <div class="container">
          <div class="row">
            <div class="col-md-12">
              <div>
                <b-table striped hover :items="filtered" :fields="fields" :per-page="perPage" :current-page="currentPage">
                  <template slot="top-row" slot-scope="{ fields }">
                  <td v-for="field in fields" :key="field.key">
                    <input v-model="filters[field.key]" :placeholder="filterText(field.label)" v-if="field.filter" style="width:100%;">
                  </td>
                </template>
                </b-table>
                <b-pagination
                      v-model="currentPage"
                      :total-rows="rows"
                      :per-page="perPage"
                      aria-controls="my-table"
                 ></b-pagination>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
</template>

<script>
///localStorage.setItem('error',this.error)
import axios from 'axios'

export default {

  name: "historylog",
  data() {
      return {
         perPage: 10,
         currentPage: 1, 
        items: [],
        fields: [{ key: 'id',label: 'ID', sortable: false,filter:true },{ key: 'description',label: 'Description',thClass: 'text-right',
         tdClass: 'text-right', sortable: false,filter:true },{ key: 'createdAt',label: 'Create Date', sortable: false ,filter:true}],
         filters: {
          id: '',
          description: '',
          createdAt: '',
        },
      }
    },
    computed: {
      filtered () {
        ///console.log('vghj')
        const filtered = this.items.filter(item => {
          return Object.keys(this.filters).every(key =>
              String(item[key]).toUpperCase().includes(this.filters[key].toUpperCase()))
        })
        return filtered.length > 0 ? filtered : [{
          id: '',
          description: '',
          createdAt: '',
        }]
      },
       rows() {
        return this.filtered.length
      }

    },
    mounted(){
      this.viewErrors();
    },
    methods:{

      filterText: function(strText) {
            return 'Filter by '+strText;
          },

     viewErrors :function(){
      axios.get('/api/view-error-log', {}).then((response)=>{
                   if(response.data.status_code==200){

                         //this.$toast.success({message:response.data.record.message})
                        ///location.replace("/Userprofile");
                        this.items=response.data.message;
                        
                        //console.log(this.items);
                    }
                    
                     else if(response.data.status_code==500)
                    {
                            this.$toast.error({message:response.data.record.message})
                                
                      
                    }else if(response.data.status_code==202)
                    {
                            this.$toast.error({message:response.data.record.message})
                                
                      
                    }
                    else if(response.data.record.status_code==403)
                    { console.log(response)

                         this.$toast.error({message:response.data.record.message})
                          localStorage.clear();
                            location.replace("/");
                      
                    }

           },(error) => {
              console.log(error);
          });
    }

    }
}

</script>
