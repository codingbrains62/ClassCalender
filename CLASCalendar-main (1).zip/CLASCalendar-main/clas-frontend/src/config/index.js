export default {
  clientid: '9c25afa0-912d-4afe-b242-2d4332052015',
  redirecturl: 'http://localhost:8080/authorize',
  authority: 'https://login.microsoftonline.com/common',
  graphscopes: ['user.read','Calendars.Read','Calendars.ReadWrite','openid','profile','Mail.Send'],
  graphendpoint: 'https://graph.microsoft.com/v1.0/me',
  appinsightsid: ''
}
