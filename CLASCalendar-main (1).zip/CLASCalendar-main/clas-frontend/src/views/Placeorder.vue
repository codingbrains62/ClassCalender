<template>
    
        
            <Placeorder />
      
    
</template>

<script>
// @ is an alias to /src
import Placeorder from '../components/Placeorder.vue'




export default {
  components: {
    Placeorder
    
  }
}
</script>
