<template>
  <div class="login_form forgotpsswrd">
    <div class="innerwrp">
        <h1 class="heading">Lets Log you in</h1>
        <p>Tell us your email &amp; we'll do the rest</p>
        <div class="error" style="display: none;"></div>
        <div class="success" style="display: none;"></div>
        <b-form @submit.prevent="Forgot">
        <b-form-group id="input-group-1" label-for="input-1"  >
            <b-form-input aria-describedby="email" id="input-1" v-model="email" type="email" placeholder="Email" required></b-form-input>
        </b-form-group>
        <b-button type="submit" class="loginbtn" variant="primary">Continue</b-button>
        </b-form>
    </div>
  </div>
</template>

<script>

import axios from 'axios'

export default {
  name: "forgot",
  data()
  {
    return {
      email: ''
    }
  },
  methods:{
      async Forgot(){
            axios.post('/api/forgot_password', {
                email: this.email
            }).then((response) => {
                //console.log(response);
                if(response.data.record.status_code == 200){
                    var eleSuccess = document.getElementsByClassName('success')[0];
                    var eleError1 = document.getElementsByClassName('error')[0];
                    eleError1.innerHTML = '';
                    eleError1.classList.remove("show");
                    eleSuccess.innerHTML= response.data.record.message;
                    eleSuccess.classList.add("show");
                }
                else if(response.data.record.status_code == 202){
                
                    var eleSuccess1 = document.getElementsByClassName('success')[0];
                    var eleError = document.getElementsByClassName('error')[0];
                    eleSuccess1.innerHTML = '';
                    eleSuccess1.classList.remove("show");
                    eleError.innerHTML= response.data.record.message;
                    eleError.classList.add("show");
                }
            },(error) => {
                console.log(error);
            });
      }
  }
}

</script>