<template>
    <div class="container">

                <cipuser/>
               
    </div>
</template>
<script>
import cipuser from '../components/cipuser.vue'


export default({
    components: {
      cipuser

  }
})
</script>
