<style>
.cus-main-btn-div {
  margin-top: 0.5rem;
  display: flex;
  align-items: center;
  justify-content: space-between;
  width: 100%;
  flex-wrap: wrap;
  margin-bottom: 0.5rem;
}

.cusBTN {
  background: #003e77;
  color: #fff;
  padding: 8px;
  border: 0;
  border-radius: 7px;
  box-shadow: 13px 6px 20px 0px #8888;
}

.cusBTN:hover {
  background: #0d5ba3;
}

.outter-box {
  position: absolute;
  width: 100%;
  background: #fff;
  z-index: 9;
  border: 1px solid #fff;
  max-height: 230px;
  overflow-y: auto;
}

.btn .b-icon.bi {
  fill: #003e77;
}

.e-schedule .e-vertical-view .e-day-wrapper .e-appointment .e-appointment-details {
  background: #099e92;
}

.e-schedule .e-vertical-view .e-day-wrapper .e-appointment:not(.e-schedule-event-clone) {
  border-radius: 7px;
}

.e-quick-popup-wrapper .e-event-popup .e-popup-header {
  background: #099e92 !important;
}

#wrapper {
  max-width: 246px;
  margin: 30px auto;
  padding-top: 15px;
}
</style>
<template>
  <div class="container schedule">
    <br>
    <br>
    <div class="cus-main-btn-div">
      <button class="cusBTN" @click="login" type="button" v-if="!user">Login with Microsoft</button>
      <button v-b-modal.modal-prevent-closingthree type="button" @click="openmd" class="cusBTN">CLASTrak</button>
      <button v-b-modal.modal-prevent-closingthree type="button" @click="open" class="cusBTN">UCC-eZFile</button>
      <button v-b-modal.modal-prevent-closingthree type="button" @click="openn" class="cusBTN">UCC-Id Search</button>
      <button v-b-modal.modal-prevent-closingthree type="button" @click="openmdd" class="cusBTN">EntityTrak</button>
    </div>
    <!-- <button @click="login" type="button" v-if="!user">Login with Microsoft</button> -->
    <!-- <b-button v-b-modal.modal-prevent-closingthree>CLASTrak</b-button> -->
    <ejs-schedule id="Schedule" ref='scheduleObj' :selectedDate='selectedDate' :popupOpen='onPopupOpen'
      :actionBegin="onActionBegin" :eventSettings='eventSettings'>
    </ejs-schedule>
    <br> <br>
    <!-- <b-button v-b-modal.modal-prevent-closingthree>CLASTrak</b-button> -->

    <!---clas trak modal-->
    <b-modal v-model='clastrakModal' ref="modal" title="CLAS-Trak" cancel-title="Close" @ok="saveClas" ok-title="Save">
      <b-form class="clastrak-form form-sec">
        <div class="e-float-input">
          <b-form-input v-model="name" placeholder="Add a Title" id="name-input" required>
          </b-form-input>
          <b-form-input v-model="clastrakid" hidden placeholder="Add a Title" id="name-input" required>
          </b-form-input>
        </div>
        <div class="e-float-input">
          <b-form-input v-model="filling" v-if='hide' v-on:keyup='SearchByclientName' placeholder="Search"
            id="filling-input" required>
          </b-form-input>
        </div>
        <div v-if='show' class="outter-box-singal">
          <div class="inner-table" v-for="searchArrays in searchClastrak">
            <div class="first-sec">
              <h5>{{ searchArrays.fullName }}</h5>
              <span class="mob-sec">({{ searchArrays.billingAccount.bookkeepingId }})</span>
              <span class="email-sec">{{ searchArrays.emailAddress }}</span>
            </div>
            <div class="second-sec">
              <p class="address-sec">{{ searchArrays.org.name }} <br>{{ searchArrays.cellPhone }}
                ,{{ searchArrays.billingAccount.addressPart1 }} , {{ searchArrays.billingAccount.addressPart2 }},
                {{ searchArrays.billingAccount.addressPart3 }}
                ,{{ searchArrays.billingAccount.addressPart4 }},{{ searchArrays.billingAccount.addressPart5 }}</p>
            </div>
          </div>
        </div>
        <div class="outter-box" v-else>
          <div class="inner-table" v-for="searchArrays in searchClastrak" @click="ClickSearchClastrak(searchArrays)">
            <div class="first-sec">
              <h5>{{ searchArrays.fullName }}</h5>
              <span class="mob-sec">({{ searchArrays.billingAccount.bookkeepingId }})</span>
              <span class="email-sec">{{ searchArrays.emailAddress }}</span>
            </div>
            <div class="second-sec">
              <p class="address-sec">{{ searchArrays.org.name }} <br>{{ searchArrays.cellPhone }}
                ,{{ searchArrays.billingAccount.addressPart1 }} , {{ searchArrays.billingAccount.addressPart2 }},
                {{ searchArrays.billingAccount.addressPart3 }}
                ,{{ searchArrays.billingAccount.addressPart4 }},{{ searchArrays.billingAccount.addressPart5 }}</p>
            </div>
          </div>
        </div>
        <div class="e-float-input d-flex pt-3">
          <div class="col-lg-6 control-section px-0">

            <div id="wrapper pt-0">
              <ejs-datetimepicker v-model="startdate" placeholder="start calendar" id="datetimepicker">
              </ejs-datetimepicker>
            </div>
          </div>
          <div class="col-lg-6 control-section pr-0">

            <div id="wrapper pt-0">
              <ejs-datetimepicker v-model="enddate" placeholder="end calendar" id="datetimepicker"></ejs-datetimepicker>
            </div>
          </div>
        </div>
        <!-- <div class="e-float-input">
            <label>Start Time</label>
            <b-form-timepicker id="start-time" v-model="starttime" class="e-control-wrapper e-input-group">
            </b-form-timepicker>
            <label>End Time</label>
            <b-form-timepicker id="end-time" v-model="endtime" class="e-control-wrapper e-input-group">
            </b-form-timepicker>
          </div> -->
        <div class="e-float-input d-flex">
          <b-form-textarea v-model="text" placeholder="Description" id="textarea" rows="3" max-rows="6">
          </b-form-textarea>
        </div>
      </b-form>
    </b-modal>
    <!---clas trak modal-->

    <!-- new Entity modal -->
    <b-modal v-model='clasentitymodel' ref="modal" title="Entity-Trak" cancel-title="Close" @ok="saveEntity"
      ok-title="Save">
      <b-form class="clastrak-form form-sec ">
        <div class="e-float-input">
          <b-form-input v-model="names" placeholder="Add a Title" id="name-input" required>
          </b-form-input>
          <b-form-input v-model="Entitytrakid" hidden placeholder="Add a Title" id="name-input" required>
          </b-form-input>
        </div>
        <div class="e-float-input">
          <b-form-input v-model="fillinge" v-if='hide' v-on:keyup='SearchByEntityTrak' placeholder="Search"
            id="filling-input" required>
          </b-form-input>
        </div>

        <div v-if='show' class="outter-box-singal">
          <div class="inner-table" v-for="searchArrays in searchEntitytrak">
            <div class="first-sec">
              <h5>{{ searchArrays.groupname }}</h5>
              <span class="mob-sec">({{ searchArrays.entityid }})</span>
              <span class="email-sec">{{ searchArrays.entityname }}</span>
            </div>
            <div class="second-sec">
              <p class="address-sec">{{ searchArrays.agentaddress }} <br>{{ searchArrays.status }}
                ,{{ searchArrays.entitytype }} , {{ searchArrays.agentcity }},
                {{ searchArrays.fiscalyearend }}
                ,{{ searchArrays.agentname }},{{ searchArrays.agentstate }}</p>
            </div>
          </div>
        </div>
        <div class="outter-box" v-else>
          <div class="inner-table" v-for="searchArrays in searchEntitytrak"
            @click="ClickSearchEntitytrak(searchArrays)">
            <div class="first-sec">
              <h5>{{ searchArrays.groupname }}</h5>
              <span class="mob-sec">({{ searchArrays.entityid }})</span>
              <span class="email-sec">{{ searchArrays.entityname }}</span>
            </div>
            <div class="second-sec">
              <p class="address-sec">{{ searchArrays.agentaddress }} <br>{{ searchArrays.status }}
                ,{{ searchArrays.entitytype }} , {{ searchArrays.agentcity }},
                {{ searchArrays.fiscalyearend }}
                ,{{ searchArrays.agentname }},{{ searchArrays.agentstate }}</p>
            </div>
          </div>
        </div>
        <div class="e-float-input d-flex pt-3">
          <div class="col-lg-6 control-section px-0">
            <div id="wrapper pt-0">
              <ejs-datetimepicker v-model="startdatee" placeholder="start calendar" id="datetimepicker">
              </ejs-datetimepicker>
            </div>
          </div>
          <div class="col-lg-6 control-section pr-0">
            <div id="wrapper pt-0">
              <ejs-datetimepicker v-model="enddatee" placeholder="end calendar" id="datetimepicker">
              </ejs-datetimepicker>
            </div>
          </div>
        </div>
        <div class="e-float-input d-flex">
          <b-form-textarea v-model="textt" placeholder="Description" id="textarea" rows="3" max-rows="6">
          </b-form-textarea>
        </div>
      </b-form>
    </b-modal>
    <!-- new Entity modal -->

    <!-----new EzNum file---->
    <b-modal v-model='clasezfilemodel' ref="modal" title="UCC-eZFile" cancel-title="Close" @ok="saveEzfile"
      ok-title="Save">
      <b-form class="clastrak-form form-sec ">
        <div class="e-float-input">
          <b-form-input v-model="namess" placeholder="Add a Title" id="name-input" required>
          </b-form-input>
          <b-form-input v-model="clasezfileid" hidden placeholder="Add a Title" id="name-input" required>
          </b-form-input>
        </div>
        <div class="e-float-input">
          <b-form-input v-model="fillings" v-if='hide' v-on:keyup='SearchByEfileNum' placeholder="Search"
            id="fillings-input" required>
          </b-form-input>
        </div>
        <div v-if='show' class="outter-box-singal">
          <div class="inner-table" v-for="searchArrays in searchEzfile">
            <div class="first-sec">
              <h5>{{ searchArrays.fullName }}</h5>
              <span class="mob-sec">({{ searchArrays.billingAccount.bookkeepingId }})</span>
              <span class="email-sec">{{ searchArrays.emailAddress }}</span>
            </div>
            <div class="second-sec">
              <p class="address-sec">{{ searchArrays.org.name }} <br>{{ searchArrays.cellPhone }}
                ,{{ searchArrays.billingAccount.addressPart1 }} , {{ searchArrays.billingAccount.addressPart2 }},
                {{ searchArrays.billingAccount.addressPart3 }}
                ,{{ searchArrays.billingAccount.addressPart4 }},{{ searchArrays.billingAccount.addressPart5 }}</p>
            </div>
          </div>
        </div>
        <div class="outter-box" v-else>
          <div class="inner-table" v-for="searchArrays in searchEzfile" @click="ClickSearchEzfile(searchArrays)">
            <div class="first-sec">
              <h5>{{ searchArrays.fullName }}</h5>
              <span class="mob-sec">({{ searchArrays.billingAccount.bookkeepingId }})</span>
              <span class="email-sec">{{ searchArrays.emailAddress }}</span>
            </div>
            <div class="second-sec">
              <p class="address-sec">{{ searchArrays.org.name }} <br>{{ searchArrays.cellPhone }}
                ,{{ searchArrays.billingAccount.addressPart1 }} , {{ searchArrays.billingAccount.addressPart2 }},
                {{ searchArrays.billingAccount.addressPart3 }}
                ,{{ searchArrays.billingAccount.addressPart4 }},{{ searchArrays.billingAccount.addressPart5 }}</p>
            </div>
          </div>
        </div>
        <div class="e-float-input d-flex pt-3">
          <div class="col-lg-6 control-section px-0">
            <div id="wrapper pt-0">
              <ejs-datetimepicker v-model="startdateee" placeholder="start calendar" id="datetimepicker">
              </ejs-datetimepicker>
            </div>
          </div>
          <div class="col-lg-6 control-section pr-0">
            <div id="wrapper pt-0">
              <ejs-datetimepicker v-model="enddateee" placeholder="end calendar" id="datetimepicker">
              </ejs-datetimepicker>
            </div>
          </div>
        </div>
        <div class="e-float-input d-flex">
          <b-form-textarea v-model="texttt" placeholder="Description" id="textarea" rows="3" max-rows="6">
          </b-form-textarea>
        </div>
      </b-form>
    </b-modal>
    <!-----new EzNum file---->
    <!----new ucc-idsearch-->
    <b-modal v-model='claseIdsearchmodel' ref="modal" title="UCC-Id Search" cancel-title="Close" @ok="saveIdsearch"
      ok-title="Save">
      <b-form class="clastrak-form form-sec ">
        <div class="e-float-input">
          <b-form-input v-model="namesss" placeholder="Add a Title" id="name-input" required>
          </b-form-input>
          <b-form-input v-model="clasIdsearch" hidden placeholder="Add a Title" id="name-input" required>
          </b-form-input>
        </div>
        <div class="e-float-input">
          <b-form-input v-model="fillingg" v-if='hide' v-on:keyup='SearchByIdSearch' placeholder="Search"
            id="fillingg-input" required>
          </b-form-input>
        </div>
        <div v-if='show' class="outter-box-singal">
          <div class="inner-table" v-for="searchArrays in searchIdsearch">
            <div class="first-sec">
              <h5>{{ searchArrays.fullName }}</h5>
              <span class="mob-sec">({{ searchArrays.billingAccount.bookkeepingId }})</span>
              <span class="email-sec">{{ searchArrays.emailAddress }}</span>
            </div>
            <div class="second-sec">
              <p class="address-sec">{{ searchArrays.org.name }} <br>{{ searchArrays.cellPhone }}
                ,{{ searchArrays.billingAccount.addressPart1 }} , {{ searchArrays.billingAccount.addressPart2 }},
                {{ searchArrays.billingAccount.addressPart3 }}
                ,{{ searchArrays.billingAccount.addressPart4 }},{{ searchArrays.billingAccount.addressPart5 }}</p>
            </div>
          </div>
        </div>
        <div class="outter-box" v-else>
          <div class="inner-table" v-for="searchArrays in searchIdsearch" @click="ClickSearchIdsearch(searchArrays)">
            <div class="first-sec">
              <h5>{{ searchArrays.fullName }}</h5>
              <span class="mob-sec">({{ searchArrays.billingAccount.bookkeepingId }})</span>
              <span class="email-sec">{{ searchArrays.emailAddress }}</span>
            </div>
            <div class="second-sec">
              <p class="address-sec">{{ searchArrays.org.name }} <br>{{ searchArrays.cellPhone }}
                ,{{ searchArrays.billingAccount.addressPart1 }} , {{ searchArrays.billingAccount.addressPart2 }},
                {{ searchArrays.billingAccount.addressPart3 }}
                ,{{ searchArrays.billingAccount.addressPart4 }},{{ searchArrays.billingAccount.addressPart5 }}</p>
            </div>
          </div>
        </div>
        <div class="e-float-input d-flex pt-3">
          <div class="col-lg-6 control-section px-0">
            <div id="wrapper pt-0">
              <ejs-datetimepicker v-model="startdateeee" placeholder="start calendar" id="datetimepicker">
              </ejs-datetimepicker>
            </div>
          </div>
          <div class="col-lg-6 control-section pr-0">
            <div id="wrapper pt-0">
              <ejs-datetimepicker v-model="enddateeee" placeholder="end calendar" id="datetimepicker">
              </ejs-datetimepicker>
            </div>
          </div>
        </div>
        <div class="e-float-input d-flex">
          <b-form-textarea v-model="textttt" placeholder="Description" id="textarea" rows="3" max-rows="6">
          </b-form-textarea>
        </div>
      </b-form>
    </b-modal>
    <!---new ucc-id search-->

  </div>
</template>
<style>
@import url(https://cdn.syncfusion.com/ej2/material.css);
</style>
<script>
import { Day, Week, WorkWeek, Month, Agenda, RecurrenceEditor, SchedulePlugin, Resize, DragAndDrop } from '@syncfusion/ej2-vue-schedule';
import { HeaderDropdown as AppHeaderDropdown } from '@coreui/vue';
import { DropDownList } from '@syncfusion/ej2-dropdowns';
import { createElement, Ajax, L10n } from '@syncfusion/ej2-base';
import axios from 'axios';
import Vue from 'vue';
Vue.use(DateTimePickerPlugin);
Vue.use(SchedulePlugin);
import { DateTimePicker } from '@syncfusion/ej2-calendars';
import { DateTimePickerPlugin } from "@syncfusion/ej2-vue-calendars";
import AuthService from '../msal/index.js';




const dataStore = new AuthService
export default {
  data() {
    return {
      name: '',
      names: '',
      namess: '',
      namesss: '',
      waterMarkText: "Select a date and time",
      clastrakModal: false,
      clasentitymodel: false,
      clasezfilemodel: false,
      claseIdsearchmodel: false,
      nameState: null,
      filling: '',
      fillinge:'',
      fillings:'',
      fillingg:'',
      startdate: '',
      enddate: '',
      startdatee: '',
      enddatee: '',
      startdateee: '',
      enddateee: '',
      startdateeee: '',
      enddateeee: '',
      fillingState: null,
      text: '',
      textt: '',
      texttt: '',
      textttt: '',
      title: '',
      starttime: '',
      endtime: '',
      startCalendar: '',
      endCalendar: '',
      areadescription: '',
      show: false,
      hide: true,
      clastrakid: '',
      Entitytrakid: '',
      clasezfileid: '',
      clasIdsearch: '',
      searchClastrak: [],
      searchEntitytrak: [],
      searchEzfile: [],
      searchIdsearch: [],
      selectedDate: new Date(),
      eventSettings: {
        dataSource: JSON.parse(localStorage.getItem('_NSCaseId')),
        fields: {
          Id: 'Id',
          subject: { name: 'Subject', validation: { required: true } },
          location: { name: 'Location', validation: { required: true } },
          startTime: { name: 'StartTime', validation: { required: true } },
          Description: { name: 'Description', validation: { required: true } },
          email_to: { name: 'email_to', validation: { required: true } },
          email_subject: { name: 'email_subject', validation: { required: true } },
          email_body: { name: 'email_body', validation: { required: true } },
          endTime: { name: 'EndTime', validation: { required: true } }
        },
      },
      user: null,
    }
  },
  provide: {
    schedule: [Day, Week, WorkWeek, Month, Agenda, Resize, DragAndDrop]
  },
  mounted() {
    this.setUser();
    dataStore.Alldataget().then(response => {
      localStorage.setItem('_NSCaseId', JSON.stringify(response));
      return;
    }, err => {
    });
    //get data from clas trak from database
    this.setClas();
    dataStore.AllClastrak().then(response => {
      var _NSCaseId = localStorage.getItem('_NSCaseId');
      var _NSCaseId_array = JSON.parse(_NSCaseId);
      console.log(_NSCaseId_array);
      var saveClas = [];
      response.forEach((value, index) => {
        var dateUTC = new Date(value.starttime);
        var dateUTC = dateUTC.getTime()
        var dateIST = new Date(dateUTC);
        dateIST.setHours(dateIST.getHours() + 6);
        dateIST.setMinutes(dateIST.getMinutes() + 30);
        var dateUTCend = new Date(value.endtime);
        var dateUTCend = dateUTCend.getTime()
        var dateISTend = new Date(dateUTCend);
        dateISTend.setHours(dateISTend.getHours() + 6);
        dateISTend.setMinutes(dateISTend.getMinutes() + 30);
        // var clasEnd = endtime+'T'+    +   '.'  +  ' 2022-09-10T06:00:00.000Z';
        // var clasStart = starttime+'T'+    +   '.'  +  ' 2022-09-10T06:00:00.000Z';
        var arr = {
          Id: value.id,
          Subject: value.title,
          StartTime: value.startCalendar,
          StartTimezone: 'India Standard Time',//data.value.start.timeZone,
          EndTimezone: 'India Standard Time',///data.value.end.timeZone,
          EndTime: value.endCalendar,//new Date (data.value.end.dateTime).toString(),              
          Description: value.areadescription,
          CategoryColor: '#1aaa55',
        }
        saveClas.push(arr);
        // console.log(dateUTC);   
        // console.log(dateUTCend);           
      });
      const clastrak_array = _NSCaseId_array.concat(saveClas);
      console.log(clastrak_array);
      localStorage.setItem('_NSCaseId', JSON.stringify(clastrak_array));
      return;
    }, err => {
    });

    //get data from Entity trak from database
    this.setEntity();
    dataStore.AllEntitytrak().then(response => {
      var _NSCaseId = localStorage.getItem('_NSCaseId');
      var _NSCaseId_array = JSON.parse(_NSCaseId);
      console.log(_NSCaseId_array);
      var saveEntity = [];
      response.forEach((value, index) => {
        var dateUTC = new Date(value.starttime);
        var dateUTC = dateUTC.getTime()
        var dateIST = new Date(dateUTC);
        dateIST.setHours(dateIST.getHours() + 6);
        dateIST.setMinutes(dateIST.getMinutes() + 30);
        var dateUTCend = new Date(value.endtime);
        var dateUTCend = dateUTCend.getTime()
        var dateISTend = new Date(dateUTCend);
        dateISTend.setHours(dateISTend.getHours() + 6);
        dateISTend.setMinutes(dateISTend.getMinutes() + 30);
        // var clasEnd = endtime+'T'+    +   '.'  +  ' 2022-09-10T06:00:00.000Z';
        // var clasStart = starttime+'T'+    +   '.'  +  ' 2022-09-10T06:00:00.000Z';
        var arr = {
          Id: value.id,
          Subject: value.title,
          StartTime: value.startCalendar,
          StartTimezone: 'India Standard Time',//data.value.start.timeZone,
          EndTimezone: 'India Standard Time',///data.value.end.timeZone,
          EndTime: value.endCalendar,//new Date (data.value.end.dateTime).toString(),              
          Description: value.areadescription,
          CategoryColor: '#1aaa55',
        }
        saveEntity.push(arr);
        // console.log(dateUTC);   
        // console.log(dateUTCend);           
      });
      const Entiytrak_array = _NSCaseId_array.concat(saveEntity);
      console.log(Entiytrak_array);
      localStorage.setItem('_NSCaseId', JSON.stringify(Entiytrak_array));
      return;
    }, err => {
      console.log(err);
    });

    //get data from Eznum from database
    this.setEznum();
    dataStore.AllEznum().then(response => {
      var _NSCaseId = localStorage.getItem('_NSCaseId');
      var _NSCaseId_array = JSON.parse(_NSCaseId);
      console.log(_NSCaseId_array);
      var saveEzfile = [];
      response.forEach((value, index) => {
        var dateUTC = new Date(value.starttime);
        var dateUTC = dateUTC.getTime()
        var dateIST = new Date(dateUTC);
        dateIST.setHours(dateIST.getHours() + 6);
        dateIST.setMinutes(dateIST.getMinutes() + 30);
        var dateUTCend = new Date(value.endtime);
        var dateUTCend = dateUTCend.getTime()
        var dateISTend = new Date(dateUTCend);
        dateISTend.setHours(dateISTend.getHours() + 6);
        dateISTend.setMinutes(dateISTend.getMinutes() + 30);
        // var clasEnd = endtime+'T'+    +   '.'  +  ' 2022-09-10T06:00:00.000Z';
        // var clasStart = starttime+'T'+    +   '.'  +  ' 2022-09-10T06:00:00.000Z';
        var arr = {
          Id: value.id,
          Subject: value.title,
          StartTime: value.startCalendar,
          StartTimezone: 'India Standard Time',//data.value.start.timeZone,
          EndTimezone: 'India Standard Time',///data.value.end.timeZone,
          EndTime: value.endCalendar,//new Date (data.value.end.dateTime).toString(),              
          Description: value.areadescription,
          CategoryColor: '#1aaa55',
        }
        saveEzfile.push(arr);
        // console.log(dateUTC);   
        // console.log(dateUTCend);           
      });
      const Eznum_array = _NSCaseId_array.concat(saveEzfile);
      console.log(Eznum_array);
      localStorage.setItem('_NSCaseId', JSON.stringify(Eznum_array));
      return;
    }, err => {
    });

    //get data from Id Search from database
    this.setIdsearch();
    dataStore.AllIdSearch().then(response => {
      var _NSCaseId = localStorage.getItem('_NSCaseId');
      var _NSCaseId_array = JSON.parse(_NSCaseId);
      console.log(_NSCaseId_array);
      var saveIdsearch = [];
      response.forEach((value, index) => {
        var arr = {
          Id: value.id,
          Subject: value.title,
          StartTime: value.startCalendar,
          StartTimezone: 'India Standard Time',//data.value.start.timeZone,
          EndTimezone: 'India Standard Time',///data.value.end.timeZone,
          EndTime: value.endCalendar,//new Date (data.value.end.dateTime).toString(),              
          Description: value.areadescription,
          CategoryColor: '#1aaa55',
        }
        saveIdsearch.push(arr);
        // console.log(dateUTC);   
        // console.log(dateUTCend);           
      });
      const Idsearch_array = _NSCaseId_array.concat(saveIdsearch);
      console.log(Idsearch_array);
      localStorage.setItem('_NSCaseId', JSON.stringify(Idsearch_array));
      return;
    }, err => {
    });
  },
  methods: {
    // clastrak-event data save on click button
    async saveClas() {
      var parameters = {
        title: this.name,
        startCalendar: this.startdate,
        endCalendar: this.enddate,
        starttime: this.starttime,
        endtime: this.endtime,
        areadescription: this.text,
        userid: localStorage.getItem('userid')
      }
      console.log(parameters)
      await axios.post('/api/clastrak-event', parameters
      ).then((response) => {
        if (response.data.record.status_code == 200) {
          this.$toast.info({ message: response.data.record.message })
          //  this.AllClastrak();
          location.replace("/dashboard");
        }
        else if (response.data.record.status_code == 203) {
          var innerHTML = response.data.record.message
          for (var i = 0; i < innerHTML.length; i++) {
            this.$toast.error({ message: innerHTML[i] })
          }
        }
        else if (response.data.record.status_code == 204) {
          this.$toast.error({ message: response.data.record.message })

        } else if (response.data.record.status_code == 202) {
          this.$toast.error({ message: response.data.record.message })

        }
        else if (response.data.record.status_code == 403) {

          this.$toast.error({ message: response.data.record.message })
          // localStorage.clear();
          location.replace("/");
        }
        console.log(response)
      },

        (error) => {
          console.log(error);
        }
      )
    },
    //entitytrak data save on click button
    async saveEntity() {
      var parameters = {
        title: this.names,
        startCalendar: this.startdatee,
        endCalendar: this.enddatee,
        starttime: this.starttime,
        endtime: this.endtime,
        areadescription: this.textt,
        userid: localStorage.getItem('userid')
      }
      console.log(parameters)
      await axios.post('/api/entitytrak-event', parameters
      ).then((response) => {
        if (response.data.record.status_code == 200) {
          this.$toast.success({ message: response.data.record.message })
          // this.AllEntitytrak();
          location.replace("/dashboard");
        }
        else if (response.data.record.status_code == 203) {
          var innerHTML = response.data.record.message
          for (var i = 0; i < innerHTML.length; i++) {
            this.$toast.error({ message: innerHTML[i] })
          }
        }
        else if (response.data.record.status_code == 204) {
          this.$toast.error({ message: response.data.record.message })

        } else if (response.data.record.status_code == 202) {
          this.$toast.error({ message: response.data.record.message })

        }
        else if (response.data.record.status_code == 403) {
          this.$toast.error({ message: response.data.record.message })
          // localStorage.clear();
          // location.replace("/");
        }
        console.log(response)
      },
        (error) => {
          console.log(error);
        }
      )
    },
    //ucc id search save on click button
    async saveIdsearch() {
      var parameters = {
        title: this.namesss,
        startCalendar: this.startdateeee,
        endCalendar: this.enddateeee,
        areadescription: this.textttt,
        userid: localStorage.getItem('userid')
      }
      console.log(parameters)
      await axios.post('/api/idsearch-event', parameters
      ).then((response) => {
        if (response.data.record.status_code == 200) {
          this.$toast.success({ message: response.data.record.message })
          location.replace("/dashboard");
        }
        else if (response.data.record.status_code == 203) {
          var innerHTML = response.data.record.message
          for (var i = 0; i < innerHTML.length; i++) {
            this.$toast.error({ message: innerHTML[i] })
          }
        }
        else if (response.data.record.status_code == 204) {
          this.$toast.error({ message: response.data.record.message })

        } else if (response.data.record.status_code == 202) {
          this.$toast.error({ message: response.data.record.message })

        }
        else if (response.data.record.status_code == 403) {
          this.$toast.error({ message: response.data.record.message })
          // localStorage.clear();
          // location.replace("/dashboard");
        }
        console.log(response)
      },
        (error) => {
          console.log(error);
        }
      )
    },

    // ucc id search save on click button

    //Ezfile data save on click button
    async saveEzfile() {
      var parameters = {
        title: this.namess,
        startCalendar: this.startdateee,
        endCalendar: this.enddateee,
        areadescription: this.texttt,
        userid: localStorage.getItem('userid')
      }
      console.log(parameters)
      await axios.post('/api/eznum-event', parameters
      ).then((response) => {
        if (response.data.record.status_code == 200) {
          this.$toast.success({ message: response.data.record.message })
          location.replace("/dashboard");
        }
        else if (response.data.record.status_code == 203) {
          var innerHTML = response.data.record.message
          for (var i = 0; i < innerHTML.length; i++) {
            this.$toast.error({ message: innerHTML[i] })
          }
        }
        else if (response.data.record.status_code == 204) {
          this.$toast.error({ message: response.data.record.message })

        } else if (response.data.record.status_code == 202) {
          this.$toast.error({ message: response.data.record.message })

        }
        else if (response.data.record.status_code == 403) {
          this.$toast.error({ message: response.data.record.message })
          // localStorage.clear();
          // location.replace("/dashboard");
        }
        console.log(response)
      },
        (error) => {
          console.log(error);
        }
      )
    },
    logout() {
      this.user = null
    },
    //login model
    login() {
      this.$AuthService.loginRedirect();
    },
    openmd() {
      this.clastrakModal = true;
    },
    openmdd() {
      this.clasentitymodel = true;
    },
    open() {
      this.clasezfilemodel = true;
    },
    openn() {
      this.claseIdsearchmodel = true;
    },
    setUser() {
      this.user = this.$AuthService.getUser()
    },
    setClas() {
      this.user = this.$AuthService.getUser()
    },
    setEntity() {
      this.user = this.$AuthService.getUser()
    },
    setEznum() {
      this.user = this.$AuthService.getUser()
    },
    setIdsearch() {
      this.user = this.$AuthService.getUser()
    },

    onActionBegin: function (args) {
      if (args.requestType === 'eventCreate' || args.requestType === 'eventChange' || args.requestType === 'eventRemove') {
        let scheduleObj = this.$refs.ScheduleObj;
        if (args.requestType === 'eventCreate') {
          var data = args.data[0];
          if (this.user == null) {
            this.AddCreateEvent(data);
            //  this.saveClas(data);
            this.clasentitymodel = false;
            this.clastrakModal = true;
            this.clasezfilemodel = false;
            this.claseIdsearchmodel = false;
          }
          else {
            this.$AuthService.CreateEvent(data).then(data => {
              this.AddCreateEvent(data);
              //  this.saveClas(data);
              this.clastrakModal = false;
              this.clasezfilemodel = false;
              this.claseIdsearchmodel = false;
              dataStore.Alldataget().then(response => {
                localStorage.setItem('_NSCaseId', JSON.stringify(response));// all data get event
              }, err => {
                console.error(err);
              });
              dataStore.AllClastrak().then(response => {
                localStorage.setItem('clasid', JSON.stringify(response));//clas trak event
              }, err => {
                console.error(err);
              });
              dataStore.AllEntitytrak().then(response => {
                localStorage.setItem('entityid', JSON.stringify(response));// entitytrak event
              }, err => {
                console.error(err);
              });
              dataStore.AllIdSearch().then(response => {
                localStorage.setItem('eznum', JSON.stringify(response));// ucc idsearch event
              }, err => {
                console.error(err);
              });
              dataStore.AllEznum().then(response => {
                localStorage.setItem('idsearch', JSON.stringify(response));// ucc Eznum fille filling pdf event
              }, err => {
                console.error(err);
              });
            }, err => {
              console.error(err);
            });
          }
        } else if (args.requestType === 'eventChange') {
          if (this.user == null) {
            this.UpdateEvent(args.data);
          } else {
            this.$AuthService.UpdateEvent(args.data).then(data => {
              this.UpdateEvent(data)
              dataStore.Alldataget().then(response => {
                localStorage.setItem('_NSCaseId', JSON.stringify(response)); //set
              }, err => {
                console.error(error);
              });
              dataStore.AllClastrak().then(response => {
                localStorage.setItem('clasid', JSON.stringify(response)); //set
              }, err => {
                console.error(err);
              });
              dataStore.AllEntitytrak().then(response => {
                localStorage.setItem('entityid', JSON.stringify(response));
              }, err => {
                console.error(err);
              });
              dataStore.AllIdSearch().then(response => {
                localStorage.setItem('eznum', JSON.stringify(response));// ucc idsearch event
              }, err => {
                console.error(err);
              });
              dataStore.AllEznum().then(response => {
                localStorage.setItem('idsearch', JSON.stringify(response));// ucc Eznum fille filling pdf event
              }, err => {
                console.error(err);
              });
            }, err => {
              console.error(err);
            });
          }
        } else if (args.requestType === 'eventRemove') {
          if (this.user == null) {
            this.DeleteEvent(args.data);
          } else {
            this.$AuthService.DeleteEvent(args.data)
            this.DeleteEvent(args.data)
            dataStore.Alldataget().then(response => {
              localStorage.setItem('_NSCaseId', JSON.stringify(response)); //set
            }, err => {
              console.error(err);
            });
            dataStore.AllClastrak().then(response => {
              localStorage.setItem('clasid', JSON.stringify(response)); //set
            }, err => {
              console.error(err);
            });
            dataStore.AllEntitytrak().then(response => {
              localStorage.setItem('entityid', JSON.stringify(response));
            }, err => {
              console.error(err);
            });
            dataStore.AllIdSearch().then(response => {
              localStorage.setItem('eznum', JSON.stringify(response));// ucc idsearch event
            }, err => {
              console.error(err);
            });
            dataStore.AllEznum().then(response => {
              localStorage.setItem('idsearch', JSON.stringify(response));// ucc Eznum fille filling pdf event
            }, err => {
              console.error(err);
            });
          }
        }
      }
    },
    onPopupOpen: function (args) {
      if (args.type === 'Editor') {
        if (!args.element.querySelector('.e-subject-container1 ')) {
          let row = createElement('div', { className: 'e-float-input e-control-wrappe e-subject-container1' });
          let formElement = args.element.querySelector('.e-schedule-form');
          formElement.firstChild.insertBefore(row, args.element.querySelector('.e-title-location-row'));
          let container = createElement('div', { className: 'custom-field-container' });
          let inputEle = createElement('input', {
            className: 'e-field e-subject ', attrs: { name: 'email_to', type: 'text', placeholder: 'To ' }
          });
          container.appendChild(inputEle);
          row.appendChild(container);
        }
        if (!args.element.querySelector('.e-subject-container2 ')) {
          let row = createElement('div', { className: 'e-float-input e-control-wrappe e-subject-container2' });
          let formElement = args.element.querySelector('.e-schedule-form');
          formElement.firstChild.insertBefore(row, args.element.querySelector('.e-title-location-row'));
          let container = createElement('div', { className: 'custom-field-container' });
          let inputEle = createElement('input', {
            className: 'e-field e-subject ', attrs: { name: 'email_subject', id: 'ghgh', type: 'text', placeholder: 'Email Subject  ' }
          });
          container.appendChild(inputEle);
          row.appendChild(container);
        }
        if (!args.element.querySelector('.e-subject-container3 ')) {
          let row = createElement('div', { className: 'e-float-input e-control-wrappe e-subject-container3' });
          let formElement = args.element.querySelector('.e-schedule-form');
          formElement.firstChild.insertBefore(row, args.element.querySelector('.e-title-location-row'));
          let container = createElement('div', { className: 'e-title-location-row' });
          let inputEle = createElement('textarea', {
            className: 'e-field  e-subject ', attrs: { name: 'email_body', placeholder: 'Email Body ' }
          });
          container.appendChild(inputEle);
          row.appendChild(container);
        }
      }
    },
    ClickSearchClastrak: function (res) {
      this.clastrakid = res.id;
      this.show = true
      this.hide = false
      var data = [];
      data.push(res);
      this.searchClastrak = data;
      console.log(this.searchClastrak)
    },
    ClickSearchEntitytrak: function (res) {
      this.Entitytrakid = res.id;
      this.show = true
      this.hide = false
      var data = [];
      data.push(res);
      this.searchEntitytrak = data;
      console.log(this.searchEntitytrak)
    },
    ClickSearchEzfile: function (res) {
      this.clasezfileid = res.id;
      this.show = true
      this.hide = false
      var data = [];
      data.push(res);
      this.searchEzfile = data;
      console.log(this.searchEzfile)

    },
    ClickSearchIdsearch: function (res) {
      this.clasIdsearch = res.id;
      this.show = true
      this.hide = false
      var data = [];
      data.push(res);
      this.searchIdsearch = data;
      console.log(this.searchIdsearch)

    },
    AddCreateEvent: function (items) {
      console.log(items);
      if (items.attendees == undefined) {
        var at = []
        var parameters = {
          calendar_id: items.Id,
          subjectName: items.Subject,
          startTime: items.StartTime,
          endTime: items.EndTime,
          location: items.Location,
          allData: items,
          descriptions: items.Description,
          recurrence: items.recurrence == null ? '' : items.recurrence,
          reminderMinutesBeforeStart: items.reminderMinutesBeforeStart,
          isAllDay: items.isAllDay,
          isReminderOn: items.isReminderOn,
          email_id: items.email_to,
          email_subject: items.email_subject,
          email_body: items.email_body,
          userid: localStorage.getItem('userid')
        }
      } else {
        var at = items.attendees[0].emailAddress.name == null ? '' : items.attendees[0].emailAddress.name.split("&");
        console.log(at)
        var parameters = {
          calendar_id: items.Id,
          subjectName: items.subject,
          startTime: items.start.dateTime,
          endTime: items.end.dateTime,
          location: items.Location,
          allData: items,
          descriptions: items.Description,
          recurrence: items.recurrence == null ? '' : items.recurrence,
          reminderMinutesBeforeStart: items.reminderMinutesBeforeStart,
          isAllDay: items.isAllDay,
          isReminderOn: items.isReminderOn,
          email_id: items.email_to,
          email_subject: items.email_subject,
          email_body: items.email_body,
          userid: localStorage.getItem('userid')
        }
      }
      axios.post('/api/add-calendar-event', parameters)
        .then((response) => {
          if (response.data.record.status_code == 200) {
            this.$toast.success({ message: response.data.record.message });
            this.Alldataget();
            location.replace("/dashboard");
          } else if (response.data.record.status_code == 202) {
            this.$toast.error({ message: response.data.record.message })
          }
          else if (response.data.record.status_code == 500) {
            this.$toast.error({ message: response.data.record.message })
          } else if (response.data.record.status_code == 203) {
            var innerHTML = response.data.record.message
            for (var i = 0; i < innerHTML.length; i++) {
              this.$toast.error({ message: innerHTML[i] })
            }
          }
        }, (error) => {
          console.error(error)
        })
    },
    UpdateEvent: function (items) {
      console.log(items)
      var parameters = {
        id: items.Id,
        subjectName: items.Subject,
        // startTime: items.StartTime,
        // endTime: items.EndTime,
        location: items.Location,
        allData: items,
        recurrence: items.recurrence == null ? '' : items.recurrence,
        reminderMinutesBeforeStart: items.reminderMinutesBeforeStart,
        isAllDay: items.isAllDay,
        descriptions: items.Description,
        isReminderOn: items.isReminderOn,
        email_id: items.email_to,
        email_subject: items.email_subject,
        email_body: items.email_body,
        userid: localStorage.getItem('userid')
      }
      axios.post('/api/update-calendar', parameters).then((response) => {
        if (response.data.record.status_code == 200) {
          this.$toast.info({ message: response.data.record.message });
          // localStorage.setItem('lastSegment', 0)
          // this.Alldataget();
          location.replace("/dashboard");
        } else if (response.data.record.status_code == 202) {
          this.$toast.error({ message: response.data.record.message })
        }
        else if (response.data.record.status_code == 500) {
          this.$toast.error({ message: response.data.record.message })
        }
        else if (response.data.record.status_code == 203) {
          var innerHTML = response.data.record.message
          for (var i = 0; i < innerHTML.length; i++) {
            this.$toast.info({ message: innerHTML[i] })//error
          }
        }
      }, (error) => { console.error(error) })
    },
    DeleteEvent: function (items) {
      axios.post('/api/delete-calendar', { id: items[0].Id }).then((response) => {
        if (response.data.record.status_code == 200) {
          this.$toast.error({ message: response.data.record.message });
          this.Alldataget();
          location.replace("/dashboard");
        } else if (response.data.record.status_code == 202) {
          this.$toast.error({ message: response.data.record.message })

        }
        else if (response.data.record.status_code == 500) {
          this.$toast.error({ message: response.data.record.message })
        }
      },
        (error) => {
          console.error(error);
        })
    },
    SearchByclientName() {
      if (this.filling) {
        const params = new URLSearchParams();
        params.append('clientname', this.filling)
        params.append('userid', 1)
        axios.get('/api3/api/v1/clientsearch', { params, headers: { 'x-api-key': '7ce276c1-9ad6-469f-9b4c-eb96e087d8c4' } }).then((response) => {
          this.searchClastrak = response.data;
        }, (error) => {
          console.error(error)
        })
      } else {
        this.searchClastrak = [];
      }
    },
    SearchByEntityTrak() {
      if (this.fillinge) {
        const params = new URLSearchParams();
        params.append('entityname', this.fillinge)
        params.append('userid', 1)
        axios.get('/api3/api/v1/entitysearch', { params, headers: { 'x-api-key': '7ce276c1-9ad6-469f-9b4c-eb96e087d8c4' } }).then((response) => {
          this.searchEntitytrak = response.data;
        }, (error) => {
          console.error(error)
        })
      } else {
        this.searchEntitytrak = [];
      }
    },
    SearchByEfileNum() {
      if (this.fillings) {
        console.log(this.fillings)
        const params = new URLSearchParams();
        params.append('eznum', this.fillings)
        params.append('userid', 50580)
        axios.post('/api3/api/v1/calendar/viewfilingpdf', { params, headers: { 'x-api-key': 'cc32d9ae-5975-4b0e-ad1d-42a91aabc2cc' } }).then((response) => {
          this.searchEzfile = response.data;
        }, (error) => {
          console.error(error)
        })
      } else {
        this.searchEzfile = [];
      }
    },
    SearchByIdSearch() {
      if (this.fillingg) {
        console.log(this.fillingg)
        const params = new URLSearchParams();
        params.append('eznum', this.fillingg)
        params.append('userid', 50580)
        axios.get('/api3/api/v1/calendar/idsearch', { params, headers: { 'x-api-key': 'cc32d9ae-5975-4b0e-ad1d-42a91aabc2cc' } }).then((response) => {
          this.searchIdsearch = response.data;
        }, (error) => {
          console.error(error)
        })
      } else {
        this.searchIdsearch = [];
      }
    },
  }
}
</script>
   