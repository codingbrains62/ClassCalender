<template>
  
    <errorlog/>
  
</template>

<script>
// @ is an alias to /src
import errorlog from '../components/errorlog.vue'



export default {
  components: {
    errorlog
  }
}
</script>
