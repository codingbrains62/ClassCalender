<template>
  <div class="login_form forgotpsswrd">
    <div class="innerwrp">
        <h1 class="heading">Reset Your Password</h1>
        <p>Enter Your New Password</p>
        <div class="error" style="display: none;"></div>
        <div class="success" style="display: none;"></div>
        <b-form @submit.prevent="Reset">
        <input id="token" v-model="token" type="hidden" />
        <b-form-group id="input-group-1" label-for="input-1"  >
            <b-form-input aria-describedby="password" id="input-1" v-model="pass" type="password" placeholder="New Password" required></b-form-input>
        </b-form-group>
        <b-form-group id="input-group-2" label-for="input-2"  >
            <b-form-input aria-describedby="confirmpass" id="input-2" v-model="confrmpass" type="password" placeholder="Confirm Password" required></b-form-input>
        </b-form-group>

        <b-button type="submit" class="loginbtn" variant="primary">Save</b-button>
        </b-form>
    </div>
  </div>
</template>

<script>

import axios from 'axios'

export default {
    data() {
        return{
            token : this.$route.query.t,
            pass : '',
            confrmpass: ''
        }
    },
    methods:{
      async Reset(){

        if(this.pass==this.confrmpass){

            if(this.validate_password()){

             axios.post('/api/reset-password', {
                token: this.token,
                password: this.pass
            }).then((response) => {
                 if(response.data.record.status_code== 202){
                  
                   this.$toast.error({message:response.data.record.message}); 
                    location.replace("/forgotpassword");
                 }
                 else  if(response.data.record.status_code== 200){
                     this.$toast.success({message:response.data.record.message}); 
                      location.replace("/");
                 }
                  else  if(response.data.record.status_code== 203){
                     this.$toast.error({message:response.data.record.message}); 
                 } else  if(response.data.record.status_code== 500){
                     this.$toast.error({message:response.data.record.message});
                      location.replace("/resetpassword"); 
                 }
            },(error) => {
                console.log(error);
            });
            }
            else
            {
                 this.$toast.error({message:"Minimum eight characters, at least one uppercase letter, one lowercase letter, one number and one special characte "});
            }
        }
        else
        {
           this.$toast.error({message:"Pasword and confirm password not match "}); 
        }

         
      },validate_password(){
        var  pass=/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/;
          if(pass.test(this.pass)){
            return true;
          }else
          {
            return false;
          }
      }
    }
}
</script>