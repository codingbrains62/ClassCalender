<template>
   
        
  <Events/>
           
</template>
<script>
import Events from '../components/Events.vue'


export default({
    components: {
      Events
  }
})
</script>
