module.exports = {
  lintOnSave: false,
  runtimeCompiler: true,
  devServer: {     
        proxy: {
            '^/api/': {
                target: 'http://localhost:1337',
                pathRewrite: { "^/api/": "/" },
                changeOrigin: true,
                ws: true,
                logLevel: "debug"
            },
           '/api2': {
                
                target: 'https://clasinfopro.clasinfo.com',
                pathRewrite: { "^/api2/": "" },
                changeOrigin: true,
                ws: true,
                logLevel: "debug"
            },
            '/api3': {
                
                target: 'http://clasinfostaging.clastechservices.com',
                pathRewrite: { "^/api3/": "" },
                changeOrigin: true,
                ws: true,
                logLevel: "debug"
            },
            '/api4': {
                
                target: 'http://entitytrak.clasinfo.com',
                pathRewrite: { "^/api3/": "" },
                changeOrigin: true,
                ws: true,
                logLevel: "debug"
            }
        }
    } 
}
