module.exports = {


   friendlyName: 'Edit user',


   description: '',
   inputs: {
      email: {
         type: 'string',
         ///required: true,
         isEmail: true,
         maxLength: 200,
         example: 'mary.sue@example.com'
      },
      fullName: {
         type: 'string',
         ///required: true,
         maxLength: 200,
         example: 'Amit shaha'
      },
      altemail: {
         type: 'string',
         /*required: true,
         isEmail: true,
         maxLength: 200,*/
         example: 'mary.sue@example.com'
      },
      id: {
         type: 'string',
         //required:true,
         example: 'user id'
      },

      phone: {
         type: 'string',
         ///required: true,
         description: 'user phone number',
         example: '9145784571'

      },
      cellphone: {
         type: 'string',
         //// required: true,
         description: 'user  Cell  phone number',
         example: '9145784571'

      }
      ,
      security_Level: {
         type: 'string',
         ////required: true,
         description: 'user  Security Level   ',
         example: 'this is lappi'

      },

      billingaddressPart1: {
         type: 'string',
         //// required: true,
         description: 'user  Security Level   ',
         example: 'this is address 1 - 5 ',
      },
      company_name: {
         type: 'string',
         //required: true,
         description: 'organization name ',
         example: 'this is lappi key '
      }

   },
   exits: {
      success: {
         status: 200,
         message: 'Record has been update successfully '
      }
   },
   fn: async function (inputs, exits) {

      var req = this.req;
      var res = this.res;

      function validate(string, email) {

         if (string.test(email)) {
            return true;
         } else {
            return false;
         }
      }
      try {
         errors = [];
         if (!validate(/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/, inputs.email)) {
            errors.push('Please enter valid email address')
         }
         if (!validate(/^[a-zA-Z ]+$/, inputs.company_name)) {

            errors.push('Company name is required');
         }
         if (!validate(/^[a-zA-Z ]+$/, inputs.fullName)) {

            errors.push('Full  Name is required');
         }

         if (!validate(/^\d{10}$/, inputs.phone)) {
            errors.push('Phone number minimum 10 digit ');
         }
         if (!inputs.billingaddressPart1) {

            errors.push('Address  is required');
         }
         if (inputs.altemail !== "") {

            if (!validate(/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/, inputs.altemail)) {
               errors.push('Alternate email address valid email id ');
            }
         }
         if (!inputs.security_Level) {

            errors.push(' Security Role is required');
         }

         if (errors.length === 0) {

            var data = {
               'fullName': inputs.fullName,
               'alternateEmailAddress': inputs.altemail,
               'phone': inputs.phone,
               'cellPhone': inputs.cellphone,
               'SecurityLevel': inputs.security_Level,

            }
            await User.update({ id: inputs.id }, data);
            var userdata = await User.findOne({ id: inputs.id });
            var data = {
               description: 'User profile update Successfully ',
               actorId: inputs.id,
               actorType: "User",
               actorDisplayName: inputs.fullName,
               category: 'Other'
            }

            await Historylog.create(data).fetch();
            var updatebyuser = [];

            var updatebyadminRequest = [];
            var update = {
               "column": 'fullName',
               'current_record': userdata.fullName,
               'new_record': inputs.fullName
            }
            updatebyuser.push(update);
            var update = {
               "column": 'alternate email',
               'current_record': userdata.alternateEmailAddress,
               'new_record': inputs.altemail
            }
            updatebyuser.push(update);
            var update = {
               "column": 'phone',
               'current_record': userdata.phone,
               'new_record': inputs.phone
            }
            updatebyuser.push(update);
            var update = {
               "column": 'cellphone',
               'current_record': userdata.cellPhone,
               'new_record': inputs.cellphone
            }
            updatebyuser.push(update);
            var update = {
               "column": 'SecurityLevel',
               'current_record': userdata.SecurityLevel,
               'new_record': inputs.security_Level
            }
            updatebyuser.push(update);
            if (updatebyuser.length > 0) {
               object = {
                  Name: inputs.fullName,
                  dataobj: updatebyuser,
                  request_page: 'edit'
               },
                  obj = {
                     to: userdata.emailAddress,
                     subject: "Edit Successfully "
                  }
               Mailer.sendforgetMail('welcomeEmail', object, obj);
            }
            if (userdata.emailAddress != inputs.email) {
               var update = {
                  "column": 'emailAddress',
                  'current_record': userdata.emailAddress,
                  'new_record': inputs.email
               }
               updatebyadminRequest.push(update)
            }
            if (userdata.address != inputs.billingaddressPart1) {
               var update = {
                  "column": 'addressPart1',
                  'current_record': userdata.address,
                  'new_record': inputs.billingaddressPart1
               }
               updatebyadminRequest.push(update)
            }
            if (userdata.company_name != inputs.company_name) {
               var update = {
                  "column": 'Company name',
                  'current_record': userdata.company_name,
                  'new_record': inputs.company_name
               }
               updatebyadminRequest.push(update)
            }
            if (updatebyadminRequest.length > 0) {

               object = {
                  Name: inputs.fullName,
                  dataobj: updatebyadminRequest,
                  request_page: 'edit'
               },
                  obj = {
                     to: 'codingbrains24@gmail.com',
                     subject: "Edit Request "
                  }
               Mailer.sendforgetMail('welcomeEmail', object, obj);
               success = {
                  status: 'success',
                  status_code: 200,
                  message: 'Updated request  has been send successfully '
               }
               res.json({ record: success })
            }
            else {
               success = {
                  status: 'success',
                  status_code: 200,
                  message: 'Record has been update successfully '
               }
               res.json({ record: success })
            }
         } else {
            for (var i = 0; i < errors.length; i++) {
               var data = {
                  description: errors[i],
                  actorUserId: 0,
                  actorType: "Other",
                  actorDisplayName: "Not Found ",
                  category: 'Other'
               }
               await Errorlog.create(data).fetch();
            }
            return res.json({ record: { status: 'error', status_code: 203, message: errors } });
         }
      }
      catch (error) {
         return res.serverError(error);
      }
   }
};
