module.exports = {
  friendlyName: 'Edit event',
  description: '',
  inputs: {
    id: {
      type: 'number',
      description: 'event id'
    }
  },
  exits: {
  },
  fn: async function (inputs, exits) {
    var req = this.req;
    var res = this.res;
    try {
      var event = await Event.findOne({ id: inputs.id }).populate('userid');
      return res.json({
        record: {
          status: "success",
          status_code: 200,
          message: event
        }
      });
    }
    catch (error) {
      return res.json({
        record: {
          status: "error",
          status_code: 500,
          message: "Internal Server Error"
        }
      });
    }
  }
};
