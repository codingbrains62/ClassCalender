module.exports = {


  friendlyName: 'View error logs',


  description: 'Display "Error logs" page.',


  exits: {

    success: {
     description:"success",
    },
     error:{
      description:'error'
    }

  },


  fn: async function (inputs,exits) {

     var req= this.req;
    var res= this.res;

    try
    {
      errorlog = await Errorlog.find({}).sort([{id:'DESC'}]);
      if(errorlog.length===0){
        return exits.error({
                    status: "error",
                    status_code:202,
                    message:"Something wont wrong ",
              });
      }
      else
      {
         return exits.success({
                    status: "success",
                    status_code:200,
                    message:errorlog,
              });

      }
    }
    catch(error){

              return res.json({record:{
                    status: "error",
                    status_code:500,
                    message:"Internal serverError ",
              }})
    } 

  }


};
