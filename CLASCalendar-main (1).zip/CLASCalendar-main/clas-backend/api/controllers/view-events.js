const schedule = require('node-schedule');


module.exports = {


  friendlyName: 'View event',


  description: 'Display event page.',


  exits: {

    success:{
      description:"success",
    },
    error:{
      description:'error'
    },
    

  },


  fn: async function (inputs,exits) {

       var res= this.res;
       var req=this.req;
       function formatdate(time) {
       
        return  new Date().toLocaleTimeString('en-US', { hour: 'numeric', hour12: true, minute: 'numeric',second:'numeric'  })
         
      }
      function NextRunAtHourMinuteSecond(hour,minute,second) {
        var dt = new Date();
         dt.setHours(dt.getHours() + parseInt(hour));
         dt.setMinutes(dt.getMinutes() + parseInt(minute));
         dt.setSeconds(dt.getSeconds() + parseInt(second) )
          return time  = dt.toLocaleTimeString('en-US', { hour: 'numeric', hour12: true, minute: 'numeric',second:'numeric' })
         
 
     }



     async  function EventRunDaily(id,lastrun,nextrun)
      {
         var  count= await Event.findOne({id:id}).select('remaining_count');
          await Event.update({id:id}).set({last_run:lastrun,next_run:nextrun,remaining_count:(count.remaining_count-1)}).fetch();
        console.log('+id'+id+'+'+lastrun+'+'+nextrun)
           
      }
      
     function dateDifferent(end_date,start_date ){
            var date1 = new Date(start_date);
           var date2 = new Date(end_date);
          var Difference_In_Time = date2.getTime() - date1.getTime();

       return  Difference_In_Days = Difference_In_Time / (1000 * 3600 * 24);

    }


      

       try{


    
     
           var events_arr = await Event.find({select: ['*']}).where({'event_status':1,next_run:{ '!=':'Expired'}}).sort([{id:'DESC'}]); 
                          if(events_arr.length!==0){
                            console.log(events_arr)
                            events_arr.map(data=>{
                               // console.log(data.frequency_type)
                                
                                if(data.frequency_type==='one_at_time'){
                                       var interval = 'Once';
                                       var id = data.id;
                                       var duration = data.duration.split("&"); 
                                       var frequency = data.frequency.split(":"); 
                                       var startDate= duration[0];
                                       var endDate  = duration[1];
                                       startDate=startDate.split('-');
                                       var nextrun_array=[];
                                       if(data.next_run!==''){
                                              var nextrun_arr = data.next_run.split(" "); 
                                              var nextrun = nextrun_arr[0]; 
                                               nextrun_array= nextrun.split('/');
                                        }
                                                                             
                                        var today = new Date(duration[1]);
                                        var dd = String(today.getDate()).padStart(2, '0');
                                        var mm = String(today.getMonth() + 1).padStart(2, '0'); 
                                        var yyyy = today.getFullYear();
                                        var durationDate = mm + '/' + dd + '/' + yyyy;
                                       var today = new Date();
                                       var dd = String(today.getDate()).padStart(2, '0');
                                       var mm = String(today.getMonth() + 1).padStart(2, '0'); 
                                       var yyyy = today.getFullYear();

                                       currentdate = dd + '/' + mm + '/' + yyyy;
                                       currentdate1 = mm + '/' + dd + '/' + yyyy;

                                        
                                       var  nextrun  = 'Expired';
                                      
                                       const rule = new schedule.RecurrenceRule();
                                       rule.hour = frequency[0];
                                       rule.minute = frequency[1];
                                       rule.second = frequency[2];
                                       rule.date = parseInt(startDate[2]);
                                       rule.month = parseInt(((startDate[1].substr(1, 1))-1));
                                       rule.year  = parseInt(startDate[0]);
                                       ///rule.tz  ="Asia/Kolkata";
                                       if(dateDifferent(durationDate,currentdate1) >=0 ){
                                        
                                             /// console.log(rule);
                                          const job = schedule.scheduleJob(rule,function(){
                                                var lastrun  = currentdate+' '+formatdate();
                                              EventRunDaily(id,lastrun,nextrun); 
                                              
                                              
                                       });
                                    }else{
                                        const job = schedule.scheduleJob(rule,function(){
                                                var lastrun  = currentdate+' '+formatdate();
                                              EventRunDaily(id,lastrun,nextrun); 
                                              
                                              
                                       });
                                    }
                                }
                                else if(data.frequency_type==='recurring'){
                                    var interval=data.frequency.split('&')[0];

                                      if(interval==='Daily'){
                                        
                                        var id = data.id;
                                        var duration = data.duration.split("&"); 
                                        var frequency = data.frequency.split("&");
                                        var nextrun_array=[]; 
                                        if(data.next_run!==''){
                                          var nextrun_arr = data.next_run.split(" "); 
                                          var nextrun = nextrun_arr[0]; 
                                           nextrun_array= nextrun.split('/');
                                        } 
                                         console.log('bsdk'+nextrun_array)
                                        var frequency_time= frequency[1].split(':');
                                        var  today = new Date(duration[1]);
                                        var dd = String(today.getDate()).padStart(2, '0');
                                        var mm = String(today.getMonth() + 1).padStart(2, '0'); 
                                        var yyyy = today.getFullYear();
                                        var durationDate = mm + '/' + dd + '/' + yyyy;
                                        var startDate= duration[0].split('-');
                                        var today = new Date();
                                        var dd = String(today.getDate()).padStart(2, '0');
                                        var mm = String(today.getMonth() + 1).padStart(2, '0'); 
                                        var yyyy = today.getFullYear();

                                        var currentdate = dd + '/' + mm + '/' + yyyy;
                                        var currentdate1 = mm + '/' + dd + '/' + yyyy;
                                         var days = 1;
                                         var today = new Date(Date.now()+days*24*60*60*1000);
                                         var dd = String(today.getDate()).padStart(2, '0');
                                         var mm = String(today.getMonth() + 1).padStart(2, '0'); 
                                         var yyyy = today.getFullYear();
                                         nowdate = dd + '/' + mm + '/' + yyyy;
                                         
                                          
                                            const rule = new schedule.RecurrenceRule();
                                         if(nextrun_array.length!==3){

                                           rule.hour = frequency_time[0];
                                           rule.minute = frequency_time[1];
                                           rule.second = frequency_time[2];
                                           rule.date=parseInt(startDate[2]);
                                           rule.month=parseInt(((startDate[1].substr(1, 1))-1));
                                           rule.year=parseInt(startDate[0])
                                         } 
                                         else {
                                             rule.hour = frequency_time[0];
                                            rule.minute = frequency_time[1];
                                            rule.second = frequency_time[2];
                                            rule.date= parseInt(nextrun_array[0]);
                                            rule.month= parseInt(((nextrun_array[1].substr(1, 1))-1));
                                            rule.year = parseInt(nextrun_array[2]);
                                         }
                                        
                                        if ( dateDifferent(durationDate, currentdate1)>=0) {
                                            //console.log(rule)
                                             if(dateDifferent(durationDate, currentdate1)==0){

                                                var lastrun  = currentdate+' '+formatdate();
                                                var  nextrun  = 'Expired';
                                            }else{
                                                 var lastrun  = currentdate+' '+formatdate();
                                                var  nextrun  = nowdate+' '+formatdate();

                                            }
                                          const job = schedule.scheduleJob(rule , function(){
                                               
                                              EventRunDaily(id,lastrun,nextrun);
                                            
                                              
                                           }); 
                                           //console.log('reccuing Daily'+durationDate+'hii'+currentdate)
                                         }

                                      }else if(interval==='Weekly'){
                                        
                                           var id   = data.id;
                                           var frequency = data.frequency.split("&");
                                           var duration = data.duration.split("&"); 
                                           var frequency_time= frequency[1].split(':');
                                           var startDate = duration[0].split('-');
                                           var nextrun_array=[];
                                          if(data.next_run!==''){
                                            var nextrun_arr = data.next_run.split(" "); 
                                            var nextrun = nextrun_arr[0]; 
                                             nextrun_array= nextrun.split('/');
                                           } 
                                            var frequency_time= frequency[1].split(':');
                                            var today = new Date(duration[1]);
                                            var dd = String(today.getDate()).padStart(2, '0');
                                            var mm = String(today.getMonth() + 1).padStart(2, '0'); 
                                            var yyyy = today.getFullYear();
                                            var durationDate = mm + '/' + dd + '/' + yyyy;
                                           var today = new Date();
                                           var dd = String(today.getDate()).padStart(2, '0');
                                           var mm = String(today.getMonth() + 1).padStart(2, '0'); 
                                           var yyyy = today.getFullYear();

                                           currentdate = dd + '/' + mm + '/' + yyyy;
                                           currentdate1 = mm + '/' + dd + '/' + yyyy;

                                           var days = 7;
                                           var today = new Date(Date.now()+days*24*60*60*1000);
                                           var dd = String(today.getDate()).padStart(2, '0');
                                           var mm = String(today.getMonth() + 1).padStart(2, '0'); 
                                           var yyyy = today.getFullYear();
                                           nowdate = dd + '/' + mm + '/' + yyyy;
                                           

                                          const rule = new schedule.RecurrenceRule();
                                         if(nextrun_array.length!==3){

                                           rule.hour = frequency_time[0];
                                           rule.minute = frequency_time[1];
                                           rule.second = frequency_time[2];
                                           rule.date=parseInt(startDate[2]);
                                           rule.month=parseInt(((startDate[1].substr(1, 1))-1));
                                           rule.year=parseInt(startDate[0]);
                                         } 
                                         else {
                                            rule.hour = frequency_time[0];
                                            rule.minute = frequency_time[1];
                                            rule.second = frequency_time[2];
                                            rule.date= parseInt(nextrun_array[0]);
                                            rule.month= parseInt(((nextrun_array[1].substr(1, 1))-1));
                                            rule.year =parseInt(nextrun_array[2]);
                                         }

                                          if(dateDifferent( durationDate,currentdate1) >= 0){
                                             if(dateDifferent(durationDate, currentdate1)==0){

                                                var lastrun  = currentdate+' '+formatdate();
                                                var  nextrun  = 'Expired';
                                            }else{
                                                 var lastrun  = currentdate+' '+formatdate();
                                                var  nextrun  = nowdate+' '+formatdate();

                                            }
                                            const job = schedule.scheduleJob(rule , function(){
                                              
                                                
                                             EventRunDaily(id,lastrun,nextrun);
                                          

                                          });

                                          }
                                      }
                                      else if(interval==='Monthly'){
                                        
                                           var id   = data.id;
                                           var duration = data.duration.split("&");
                                            var startDate=duration[0].split('-') 
                                            var frequency = data.frequency.split("&"); 
                                            var nextrun_array=[];
                                            if(data.next_run!==''){
                                              var nextrun_arr = data.next_run.split(" "); 
                                              var nextrun = nextrun_arr[0]; 
                                               nextrun_array= nextrun.split('/');
                                            } 
                                            var frequency_time= frequency[1].split(':');
                                            var frequency_time= frequency[1].split(':');
                                            var today = new Date(duration[1]);
                                            var dd = String(today.getDate()).padStart(2, '0');
                                            var mm = String(today.getMonth() + 1).padStart(2, '0'); 
                                            var yyyy = today.getFullYear();
                                            var durationDate = mm + '/' + dd + '/' + yyyy;

                                           var today = new Date();

                                           var dd = String(today.getDate()).padStart(2, '0');
                                           var mm = String(today.getMonth() + 1).padStart(2, '0'); 
                                           var yyyy = today.getFullYear();

                                           currentdate = dd + '/' + mm + '/' + yyyy;
                                           currentdate1 = mm + '/' + dd + '/' + yyyy;

                                           var days = 30;
                                           var today = new Date(Date.now()+days*24*60*60*1000);
                                           var dd = String(today.getDate() ).padStart(2, '0');
                                           var mm = String(today.getMonth() + 1).padStart(2, '0'); 
                                           var yyyy = today.getFullYear();
                                           nowdate = dd + '/' + mm + '/' + yyyy;
                                          
                                           const rule = new schedule.RecurrenceRule();
                                         if(nextrun_array.length!==3){

                                           rule.hour = frequency_time[0];
                                           rule.minute = frequency_time[1];
                                           rule.second = frequency_time[2];
                                           rule.date=parseInt(startDate[2]);
                                           rule.month=parseInt(((startDate[1].substr(1, 1))-1));
                                           rule.year=parseInt(startDate[0]);
                                         } 
                                         else {
                                            rule.hour = frequency_time[0];
                                            rule.minute = frequency_time[1];
                                            rule.second = frequency_time[2];
                                            rule.date= parseInt(nextrun_array[0]);
                                            rule.month= parseInt(((nextrun_array[1].substr(1, 1))-1));
                                            rule.year = parseInt(nextrun_array[2]);
                                         }
                                               
                                            if(dateDifferent(durationDate,currentdate1)>=0){
                                                if(dateDifferent(durationDate, currentdate1)==0){

                                                var lastrun  = currentdate+' '+formatdate();
                                                var  nextrun  = 'Expired';
                                            }else{
                                                 var lastrun  = currentdate+' '+formatdate();
                                                var  nextrun  = nowdate+' '+formatdate();

                                            }
                                                const job = schedule.scheduleJob(rule, function(){
                                                  
                                                    
                                                   EventRunDaily(id,lastrun,nextrun);
                                                  

                                              });
                                            } 
                                      }
                                }
                                else if(data.frequency_type==='daily_every'){

                                        var id = data.id;
                                        var duration = data.duration.split("&"); 
                                        var  endDate=duration[1].split('-');
                                       
                                    /// console.log(data)
                                        var frequency = data.frequency.split("&");
                                        if(data.next_run!==''){
                                          var nextrun_arr = data.next_run.split(" "); 
                                          var nextrun_arrr = nextrun_arr[0].split('/'); 
                                          var frequency_time = nextrun_arr[1].split(':');
                                        }else{

                                         var frequency_time= frequency[3].split(':'); 
                                       /// console.log(frequency)
                                        }
                                        var  today = new Date(duration[1]);
                                        var dd = String(today.getDate()).padStart(2, '0');
                                        var mm = String(today.getMonth() + 1).padStart(2, '0'); 
                                        var yyyy = today.getFullYear();
                                        var durationDate = mm + '/' + dd + '/' + yyyy;
                                        var startDate= duration[0].split('-');
                                        var today = new Date();
                                        var dd = String(today.getDate()).padStart(2, '0');
                                        var mm = String(today.getMonth() + 1).padStart(2, '0'); 
                                        var yyyy = today.getFullYear();
                                        var currentdate = dd + '/' + mm + '/' + yyyy;
                                        var currentdate1 = mm + '/' + dd + '/' + yyyy;
                                         var days = 1;
                                         var today = new Date(Date.now()+days*24*60*60*1000);
                                         var dd = String(today.getDate()).padStart(2, '0');
                                         var mm = String(today.getMonth() + 1).padStart(2, '0'); 
                                         var yyyy = today.getFullYear();
                                         nowdate = dd + '/' + mm + '/' + yyyy;
                                         
                                          
                                            const rule = new schedule.RecurrenceRule();
                                         if(data.next_run ===''){

                                           rule.hour = frequency_time[0];
                                           rule.minute = frequency_time[1];
                                           rule.second = frequency_time[2];
                                           rule.date=parseInt(startDate[2]);
                                           rule.month=parseInt(((startDate[1].substr(1, 1))-1));
                                           rule.year=parseInt(startDate[0])
                                           var startTime = new Date(
                                            parseInt(startDate[0]),
                                            parseInt(((startDate[1].substr(1, 1))-1)),
                                            parseInt(startDate[2]),
                                            frequency_time[0].replace(/^0+/, ''),
                                            frequency_time[1].replace(/^0+/, ''),
                                            frequency_time[2].replace(/^0+/, ''),frequency_time[2]/1000);

                                          /// console.log('hh')
                                         } 
                                         else{
                                           rule.hour = frequency_time[0];
                                           rule.minute = frequency_time[1];
                                           rule.second = frequency_time[2];
                                           rule.date=parseInt(nextrun_arrr[0]);
                                           rule.month=parseInt(((nextrun_arrr[1].substr(1, 1))-1));
                                           rule.year=parseInt(nextrun_arrr[2])
                                           var startTime = new Date(
                                            parseInt(nextrun_arrr[0]),
                                            parseInt(((nextrun_arrr[1].substr(1, 1))-1)),
                                            parseInt(nextrun_arrr[2]),
                                            frequency_time[0].replace(/^0+/, ''),
                                            frequency_time[1].replace(/^0+/, ''),
                                            frequency_time[2].replace(/^0+/, ''),frequency_time[2]/1000);
                                         }
                                        
                                        
                                        const EndTime = new Date(
                                            parseInt(endDate[0]),
                                            parseInt(((endDate[1].substr(1, 1))-1)),
                                            parseInt(endDate[2]),
                                            frequency_time[0].replace(/^0+/, ''),
                                            frequency_time[1].replace(/^0+/, ''),
                                            frequency_time[2].replace(/^0+/, ''),frequency_time[2]/1000);


                                         //console.log(startTime+''+EndTime)
                                        if ( dateDifferent(durationDate, currentdate1)>=0) {
                                            //console.log(rule)
                                            if(dateDifferent(durationDate, currentdate1)==0){

                                                var lastrun  = currentdate+' '+formatdate();
                                                var  nextrun  = 'Expired';
                                            }else{
                                                 var lastrun  = currentdate+' '+formatdate();
                                                var  nextrun  = nowdate+' '+NextRunAtHourMinuteSecond(frequency[0],frequency[1],frequency[2]);

                                            }
                                               
                                          const job = schedule.scheduleJob({ start: startDate, end: endDate,rule:rule }, function(){
                                               
                                              EventRunDaily(id,lastrun,nextrun);
                                            
                                              
                                                 // console.log('reccuing Daily'+durationDate+'hii'+currentdate)
                                           }); 
                                         }


                                    
                                } 
                                
                            })
                            
                          } 
                 events = await Event.find({select: ['*']}).sort([{id:'DESC'}]);
                 
                  if(events.length===0)
                  {
                     return res.json({record:{
                              status: "error",
                              status_code:200,
                              message:[],
                        }});
                  }
                  else
                  {
                    var  new_arr=[];
                    for (var k = 0; k < events.length; k++) {


                                     
                        var newarray='';
                         
                             var duration= events[k].duration.split('&');

                             if(events[k].frequency_type==='one_at_time'){
                                  var interval= 'Once';
                              }
                              else if(events[k].frequency_type==='recurring'){
                                  var interval=events[k].frequency.split('&')[0];
                              }
                              else if(events[k].frequency_type==='daily_every'){
                                   var interval='Daily Every';
                              }
                           
                               newarray={
                                "id":events[k].id,                        
                                "event_name":events[k].event_name.toUpperCase(),
                                 "group":events[k].group, 
                                 "duration":duration[0]+' - '+duration[1], 
                                 "interval":interval, 
                                 "last_run":events[k].last_run, 
                                 "next_run":events[k].next_run, 
                                 "repeat":5, 
                                 "remaining_count":events[k].remaining_count, 
                                }
                            new_arr.push(newarray);
                           
                       ///if(duration[0]===Date.now()) 
                                  
          } 
           return res.json({record:{
                    status: "success",
                    status_code:200,
                    message:new_arr,
              }});
        }

             
       }
       catch(error){
        return res.serverError(error);

        return res.json({record:{
                    status: "error",
                    status_code:500,
                    message:"Internal serverError ",
              }});
        
       }

  }


};
