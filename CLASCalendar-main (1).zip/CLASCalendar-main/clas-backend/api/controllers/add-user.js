module.exports = {


  friendlyName: 'Add user',


  description: '',


  inputs: {
    username:{
      type: 'string',
      example: 'Amit Sharma'
    },
    password:{
       type: 'string',
       description: 'Securely hashed representation of the user\'s login password.',
       example: '2$28a8eabna301089103-13948134nad'
    }
    ,
     fullName:{
       type: 'string',
       example: 'Amit shaha'
    },

   
    email:{
       type: 'string',
       example: 'mary.sue@example.com'
    },
    altemail:{
       type: 'string',
       example: 'mary.sue@example.com'
    },
   
    phone:{
      type: 'string',
      description:'user phone number',
      example:'9145784571'
      
    },
     cellphone:{
      type: 'string',
      description:'user  Cell  phone number',
      example:'9145784571'
    }
    ,
    security_Level:{
      type: 'string',
      description:'user  Security Level   ',
      example:'this is lappi'
    },

   billingaddressPart1:{
        type: 'string',
        description:'user  Security Level   ',
        example:'this is address 1 - 5 ',

   },
    company_name:{
        type: 'string',
        description:'organization name ',
        example:'this is lappi key '
   },
   created_by:{
        type: 'string',
        description:'this User  created_by  id'
        
   }

  },


  exits: {
    success:{
      status:200,
      message:'Record has been update successfully '
    }
  },


  fn: async function (inputs,exits) {

    var req=this.req;
    var res=this.res;

       function validation(string,email){

            if (string.test(email))
                {
                   return true;
                }else{
                   return  false;
                }

        }

        var errors=[];
        if(!validation(/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/,inputs.email)){

            errors.push('Please enter valid email address')
        }

        if(!validation(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/,inputs.password)){

            errors.push('Minimum eight characters, at least one uppercase letter, one lowercase letter, one number and one special characte');


        }
        if(!validation(/^[A-Za-z ]+$/,inputs.company_name)){
          errors.push('Please enter company name only allowed alphabet');
        }
        if(!validation(/^[A-Za-z ]+$/,inputs.fullName)){
          errors.push('Please enter Name');
        }
        if(!validation(/^\S*$/,inputs.username)|| !inputs.username){
          errors.push('Please enter Username');
        }

        if(!validation(/^\d{10}$/,inputs.phone)){
          errors.push('Please enter phone number');
        }
        if(!inputs.billingaddressPart1){
            errors.push('Please enter address');
        }
        if(inputs.altemail !== "")
         {

            if(!validation(/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/,inputs.altemail))
             {
                
                errors.push('Please enter valid altname email  id ')
             }
             if(inputs.email==inputs.altemail)
             {
              
                errors.push('Please enter different email alternate  email  ')
             }
         }



         try{

            if(errors.length===0){

                exitsemailid =   await  User.find({ 'emailAddress':inputs.email});

                //console.log(exitsemailid.length);
                if(exitsemailid.length===0){

                   data = {
                         username:inputs.username,
                         password:inputs.password,
                         fullName:inputs.fullName,
                         emailAddress:inputs.email,
                         alternateEmailAddress:inputs.altemail,
                         phone:inputs.phone,
                         cellPhone:inputs.cellphone,
                         SecurityLevel:inputs.security_Level,
                         address:inputs.billingaddressPart1,
                         company_name:inputs.company_name,
                         mandate:'Corporate',
                         createdBy:inputs.created_by
                    } 
                     var client = await User.create(data).fetch();
                      var datasave= {
                          description:'Add user insert Successfully ',
                          actorId:client.id,
                          actorType:'Client',
                          actorDisplayName:inputs.fullName,
                          category:'Other'
                        }
                        var save =  await Historylog.create(datasave).fetch();

                        return res.json({record:{
                          status:'success',
                          status_code:200,
                          message:'User added successfully ',
                          data:data
                        }});

                }else
                {
                   return  res.json({record:{
                        status:'error',
                        status_code:204,
                        message:"This Email Address already exits "
                    }})
                }

            }
            else{

                for (var i = 0; i < errors.length; i++) {
                var data= {
                                description:errors[i],
                                actorUserId:0,
                                actorType:"Other",
                                actorDisplayName:"Not Found ",
                                category:'Other'
                          }
                  await Errorlog.create(data).fetch();
                  
              }
            return res.json({record:{ status:'error',status_code:203,message:errors}})
            }

         }
         catch(error){

            // return res.serverError(error)
                return   res.json({record:{
              status:'error',
              status_code:500,
              message:'Internal  Server Error ',
            }});
            
         }




  }


};
