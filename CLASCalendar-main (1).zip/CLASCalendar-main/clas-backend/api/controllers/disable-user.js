module.exports = {


  friendlyName: 'Disable user',


  description: '',


  inputs: {

      id:{
      type:'number',
      description:'Disable User Id'
    }
  },

  exits: {

  },


  fn: async function (inputs,exits) {

       var res= this.res;
       var req= this.req;
        try{

        var users= await User.findOne({id:inputs.id});
        if(users)
        {
          if(users.isDisabled==1){
            await User.update({id:inputs.id},  {isDisabled:0});
             res.json({
                record:{
                  status:'success',
                  status_code:200,
                  message:"User Status successfully updated",
                }
               })
          }
          else if(users.isDisabled==0){
             await User.update({id:inputs.id},  {isDisabled:1});
              res.json({
                record:{
                  status:'success',
                  status_code:200,
                  message:"User Status successfully updated",
                }
               })
          }

        }
        else{
          res.json({
            record:{
              status:'error',
              status_code:202,
              message:"User not found",
            }
           })
        }
    }
    catch(error)
    {
       res.json({
        record:{
          status:'error',
          status_code:500,
          message:"Internal Server Error",
        }
       })
    }

    

  }


};
