/**
 * ClasTrakDataController
 *
 * @description :: Server-side actions for handling incoming requests.
 * @help        :: See https://sailsjs.com/docs/concepts/actions
 */
module.exports = {
  friendlyName: 'Get clastrak event',
  description: '',
  inputs: {
    user: {
      type: 'number',
      description: 'user id'
    }
  },
  exits: {
  },
  fn: async function (inputs, exits) {
    var res = this.res;
    var req = this.req;
    try {
      data = await Clastrak.find({ select: ['*'] }).where({ userid: inputs.user }).sort([{ id: 'DESC' }]);
      if (data.length === 0) {
        return exits.error({
          status: "error",
          status_code: 202,
          message: "Something wont wrong ",
        });
      }
      else {
        return exits.success({
          status: "success",
          status_code: 200,
          message: data,
        });
      }
    }
    catch (error) {
      return res.json({
        record: {
          status: "error",
          status_code: 500,
          message: "Internal serverError"+error,
        }
      });
    }
  }
};

