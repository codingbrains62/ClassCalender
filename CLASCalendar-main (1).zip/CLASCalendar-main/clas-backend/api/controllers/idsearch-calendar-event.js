module.exports = {
  friendlyName: 'Add idSearch event',
  description: '',

  inputs: {
    title: {
      type: 'string',
      description: 'title',
    },
    areadescription: {
      type: 'string',
      description: 'areadescription',
    },
    startCalendar: {
      type: "string",
      description: 'startCalendar',

    },
    endCalendar: {
      type: "string",
      description: 'endCalendar',
    },
    userid: {
      type: 'number',
      description: 'user id ',
    },
    email: {
      type: 'string',
      description: 'email',
    },
  },
  exits: {
  },
  fn: async function (inputs, exits) {
    res = this.res;
    req = this.req;
    var errors = [];
    try {
      if (errors.length == 0) {
        item = {
          title: inputs.title,
          startCalendar: inputs.startCalendar,
          endCalendar: inputs.endCalendar,
          areadescription: inputs.areadescription,
          userid: inputs.userid,
        }
        try {
          var client = await Idsearch.create(item).fetch();
          if (client) {
            console.log(client);
            return res.json({
              record: {
                status_code: 200,
                status: 'success',
                message: 'Idsearch event added successfully '
              }
            });
          } else {
            return res.json({
              record: {
                status_code: 202,
                status: 'error',
                message: 'Idsearch event Somthing error'
              }
            });
          }
        } catch (error) {
          return res.json({
            record: {
              status_code: 500,
              status: 'error',
              message: 'Internal have a  Server Error  '
            }
          });
        }
      } else {
        for (var i = 0; i < errors.length; i++) {
          var data = {
            description: errors[i],
            actorUserId: 0,
            actorType: "Other",
            actorDisplayName: "Not Found ",
            category: 'Other'
          }
          await Errorlog.create(data).fetch();
        }
        return res.json({ record: { status: 'error', status_code: 203, message: errors } });
      }
    }
    catch (error) {
      return res.serverError(error);
    }
  }
};





