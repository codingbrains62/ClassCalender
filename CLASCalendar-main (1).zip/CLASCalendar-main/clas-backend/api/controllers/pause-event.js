module.exports = {


  friendlyName: 'Pause event',


  description: '',


  inputs: {
    id:{
      type:'number',
      description: 'event id '
    }
  },


  exits: {

  },


  fn: async function (inputs) {

      var res= this.res;
      var req= this.req

      try{


        await Event.update({id:inputs.id},{event_status:0}).fetch()
            return res.json({record:{
              status:"success",
              status_code:200,message:'Event Pause successfully',
             }});

      }catch(error){
         return res.json({record:{
          status:"error",
          status_code:500,message:'Internal Server Error',
         }})

      }

  }


};
