module.exports = {


  friendlyName: 'Delete calendar event',


  description: '',


  inputs: {
    calendar_id: {
      type: 'number',
      description: 'Remove user id'
    },
    id: {
      type: 'number',
      description: 'remove event id'
    }
  },


  exits: {

  },


  fn: async function (inputs,exits) {
  
    res = this.res
    req = this.req
    try {
     
      data = await Calendar_event.destroyOne({ id: inputs.id });
      if (data) {
        return res.json({
          record: {
            status_code: 200,
            status: 'success',
            message: 'event successfully deleted'
          }
        });
      } else {
        return res.json({
          record: {
            status_code: 202,
            status: 'error',
            message: 'Something  error in delete'
          }
        });
      }
    } catch (error) {

      return res.json({
        record: {
          status_code: 500,
          status: 'error',
          message: 'Internal Server Error  '
        }
      });
    }

  }


};
