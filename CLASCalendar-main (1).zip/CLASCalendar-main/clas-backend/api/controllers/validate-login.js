
 bcrypt = require('bcrypt'); 
 const jwt = require("jsonwebtoken");
module.exports = {


  friendlyName: 'Validate login',


  description: '',


  inputs: {
    username:{
      type:'string',
      description:'username for login'
    },
    password:{
      type:'string',
      description:'password for login'
    }

  },


  exits: {
    success:{
     statusCode: 200,
      description: 'Successfully '
   }

  },


  fn: async function (inputs,exits) {

   var res= this.res;
   var req= this.req;

   try{
          function validation(string)
          {
              if (/^\S*$/.test(string))
                {
                   return true;
                }
                else{
                   return  false;
                }
          }
          var   errors=[];

          if(!validation(inputs.username)|| !inputs.username){
            errors.push('Please enter username');
          }
          if(!inputs.password){
            errors.push('Please enter password');

          }



          if(errors.length===0){
         
            //console.log(res)
             var user =    await User.findOne({'username':inputs.username});

                if(user)
                {

                  if(user.isDisabled== ''){
                     function passwordCompare(pass1,pass2){
                       return new Promise(function(resolve, reject) {
                        bcrypt.compare(pass1, pass2, function(err, res) {
                            if (err) {
                                 reject(err);
                            } else {
                                 resolve(res);
                            }
                        });
                    });
                  }

                 const password  =await passwordCompare(inputs.password , user.password);

                  if(password){

                      const token=  jwt.sign({
                          data: user.username
                        }, 'secret', { expiresIn: '7D' });

                     
                       res.cookie('jwt', token, {
                               expires: new Date(Date.now() + 300000000),
                               httpOnly: true
                          });
                     // req.headers('auth',token);
                     let lastseen = Date.now();

                     await User.update({'id':user.id},{token:token,lastSeenAt:lastseen});
                     /* var data= {
                              description:'login Successfully',
                              actorId:user.id,
                              actorType:'Client',
                              actorDisplayName:user.fullName,
                              category:'Login'
                            }
                      var dataobj = await  Historylog.create(data).fetch();*/

                      user.token=token;
                     return  res.json({record:{
                      status_code:200,
                      status:'success',
                      message: user.emailAddress +' has been logged in',
                      data: user,
                     }});

                  }else{

                    

                      return res.json({record:{
                           status:'error',
                            status_code:202,
                            message:'Invalid Password ',
                      }});
                  }

                  }else{

                  return res.json({record:{status:'error',status_code:202,message:'User has been deactive Please contect admin'}})

                  }
                  
                }
                else
                {
                  
                   var data= {
                                description:'Username not Found',
                                actorUserId:0,
                                actorType:"Other",
                                actorDisplayName:"Not Found ",
                                category:'Other'
                          }
                  await Historylog.create(data).fetch();
                  return res.json({record:{ status:'error',status_code:202,message:'This username not found'}})

                }

          }
          else{

              for (var i = 0; i < errors.length; i++) {
                var data= {
                                description:errors[i],
                                actorUserId:0,
                                actorType:"Other",
                                actorDisplayName:"Not Found ",
                                category:'Other'
                          }
                  await Errorlog.create(data).fetch();
              }
            return res.json({record:{ status:'error',status_code:203,message:errors}})
          }



   }
   catch(error){
     //return res.serverError(error)
                  res.json({record:{
              status:'error',
              status_code:500,
              message:'Internal  Server Error ',
            }});
            return ;
   }


  }


};
