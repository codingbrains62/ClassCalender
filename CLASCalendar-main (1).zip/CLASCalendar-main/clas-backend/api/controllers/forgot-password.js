module.exports = {


  friendlyName: 'Forgot password',


  description: '',


  inputs: {   
    email:{
      type:'string',
      description:' password for Forgot '
    }
  },


  exits: {
   success:{
     statusCode: 200,
      description: 'Successfully '
   }
  },


  fn: async function (inputs) {

      var res= this.res;
      var req= this.req;

      try{
            function emailValidation(string){
              if (/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(string))
                {
                   return true;
                }else{
                  return  false;
                }
            }

           var  errors=[];
         

         
          if(!emailValidation(inputs.email))
         {
            errors.push('Please enter valid email ')
         }

           if(errors.length===0){

              var user= await User.find({ where: {'emailAddress':inputs.email},limit: 1,sort: 'id DESC'});
              if(user.length>0){

                function token_generate(length) {
                    var result           = '';
                    var characters       = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
                    var charactersLength = characters.length;
                    for ( var i = 0; i < length; i++ ) {
                      result += characters.charAt(Math.floor(Math.random() * charactersLength));              
                   }
                   return result;

                }


                  token=token_generate(20);

                  user[0].password_reset_token=token;
                  object=  {
                     Name: user[0].fullName,
                     accessToken: "localhost:8080/resetpassword?t="+user[0].password_reset_token,
                     request_page:'forget'
                     },
                     obj={
                     to: user[0].emailAddress,
                     subject: "Forget password"
                     }
                     Mailer.sendforgetMail('welcomeEmail',object,obj);
                  await User.update({'id':user[0].id},{password_reset_token:token}).fetch();
                  
                  return res.json({record:{
                    status:'success',
                    status_code:200,
                     message: "Check to this email "+ user[0].emailAddress +'  click then  redirect reset password  ',
                        data:user[0] ,
                       
                   }});
                      

              }else{

                return res.json({record:{ status:'error',status_code:202,message:'Email address Not found'}})
              }


              
           }
           else
           {
              for (var i = 0; i < errors.length; i++) {
                var data= {
                                description:errors[i],
                                actorUserId:0,
                                actorType:"Other",
                                actorDisplayName:"Not Found ",
                                category:'Other'
                          }
                  await Errorlog.create(data).fetch();
              }
            return res.json({record:{ status:'error',status_code:203,message:errors}})
           }


      }
      catch(error){

       return  res.json({record:{
              status:'error',
              status_code:500,
              message:'Internal  Server Error ',
            }});
            
      }


  }


};
