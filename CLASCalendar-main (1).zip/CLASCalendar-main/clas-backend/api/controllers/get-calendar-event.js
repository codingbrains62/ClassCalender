module.exports = {


  friendlyName: 'Get calendar event',


  description: '',


  inputs: {
    user:{
      type:'number',
      description:'user id'
   }
   
  },


  exits: {

  },


  fn: async function (inputs,exits) {


    var res= this.res;
    var req=this.req;

    try{


 
   data = await Calendar_event.find({select: ['allData']}).where({userid:inputs.user}).sort([{id:'DESC'}]);
   
        
        return exits.success({
                 status: "success",
                 status_code:200,
                 message:data,
           });
    }
    catch(error){

     return res.json({record:{
                 status: "error",
                 status_code:500,
                 message:"Internal serverError ",
           }});
     
    }

              
                  
                 
  }


};

