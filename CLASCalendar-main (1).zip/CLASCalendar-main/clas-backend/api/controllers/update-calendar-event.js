module.exports = {
  friendlyName: 'Update calendar event',
  description: '',
  inputs: {
    id: {
      type: 'number',
      description: 'event id'
    },
    calendar_id: {
      type: 'string',
      description: 'Calendar id ',
    },
    subjectName: {
      type: 'string',
      description: 'This is not an association-- it is another copy of the user id,  in case the user is deleted.',
    },
    startTime: {
      type: 'number',
      description: 'This is not an association-- it is another copy of the user id,  in case the user is deleted.',
    },
    endTime: {
      type: 'number',
      description: 'This is to point the user id to the proper table',
    },
    location: {
      type: 'json',
      description: 'location calendar event ',
    },
    allData: {
      type: 'json',
      description: 'all calendar data ',
    },
    recurrence: {
      type: 'string',
      description: 'recurrence ',
    },
    reminderMinutesBeforeStart: {
      type: 'string',
      description: 'reminderMinutesBeforeStart time',
    },
    isAllDay: {
      type: 'boolean',
      description: ' isAllDay true or false ',
    },
    isReminderOn: {
      type: 'boolean',
      description: 'isReminderOn true or false ',
    },
    userid: {
      type: 'number',
      description: 'user id '
    },
    email_id: {
      type: 'string',
      description: 'email id '
    },
    email_subject: {
      type: 'string',
      description: 'email subject ',
    },
    email_body: {
      type: 'string',
      description: 'email body ',
    }
  },
  exits: {
  },
  fn: async function (inputs, exits) {
    res = this.res
    req = this.req
    var errors = [];
    function validate(string, text) {
      if (string.test(text)) {
        return true;
      } else {
        return false;
      }
    }
    errors = [];
    if (!validate(/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/, inputs.email_id)) {
      errors.push('Please enter valid email address')
    }
    //  if (!validate(/^[a-zA-Z ]+$/, inputs.company_name)) {

    //     errors.push('Company name is required');
    //  }
    //  if (!validate(/^[a-zA-Z ]+$/, inputs.email)) {

    //     errors.push('Full  Name is required');
    //  }

    //  if (!inputs.billingaddressPart1) {

    //     errors.push('Address  is required');
    //  }
    //  if (inputs.altemail !== "") {

    //     if (!validate(/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/, inputs.altemail)) {
    //        errors.push('Alternate email address valid email id ');
    //     }
    //  }

    try {
      if (errors.length === 0) {
    
        data = {
          
          subjectName: inputs.subjectName,
          startTime: inputs.startTime,
          endTime: inputs.endTime,
          location: inputs.location,
          allData: inputs.allData,
          recurrence: inputs.recurrence,
          reminderMinutesBeforeStart: inputs.reminderMinutesBeforeStart,
          isAllDay: inputs.isAllDay,
          isReminderOn: inputs.isReminderOn,
          userid: inputs.userid,
          email_id: inputs.email_to,
          email_subject: inputs.email_subject,
          email_body: inputs.email_body,
        }
        try {
          var client = await Calendar_event.update({ id: inputs.id }, data).fetch();
          if (client) {
            return res.json({
              record: {
                status_code: 200,
                status: 'success',
                message: 'event updated successfully '
              }
            });
          } else {
            return res.json({
              record: {
                status_code: 202,
                status: 'error',
                message: 'Something  error in update'
              }
            });
          }
        } catch (error) {
          return res.json({
            record: {
              status_code: 500,
              status: 'error',
              message: 'Internal Server Error  '
            }
          });
        }
      } else {
        for (var i = 0; i < errors.length; i++) {
          var data = {
            description: errors[i],
            actorUserId: 0,
            actorType: "Other",
            actorDisplayName: "Not Found ",
            category: 'Other'
          }
          await Errorlog.create(data).fetch();
        }
        return res.json({ record: { status: 'error', status_code: 203, message: errors } });
      }
    }
    catch (error) {
      return res.serverError(error);
    }
  }

};
