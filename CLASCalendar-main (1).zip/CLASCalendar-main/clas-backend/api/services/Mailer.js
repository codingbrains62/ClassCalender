module.exports.sendforgetMail = function(title,object,obj) {


 sails.hooks.email.send(
    title, 
    object,
    obj,
 function(err) {console.log(err || "Mail Sent!");}
 )
}