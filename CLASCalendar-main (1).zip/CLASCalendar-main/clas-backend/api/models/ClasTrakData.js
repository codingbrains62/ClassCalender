/**
 * ClasTrakData.js
 *
 * @description :: A model definition represents a database table/collection.
 * @docs        :: https://sailsjs.com/docs/concepts/models-and-orm/models
 */
module.exports = {
  attributes: {
    title:{
      type: 'string',
      description:'title',
    },
    // starttime:{
    //   type: 'string',
    //   description:'first name',
    // },
    areadescription:{
      type: 'string',
      description:'area address',
    },
    startCalendar:{
     type:"string",
     description:'start calendar',
    },
    endCalendar:{
      type:"string",
      description:'end calendar',
    },
    userid: {
      model:'User',
      description:'user id ',
    },
    // endtime:{
    //   type: 'string',
    //   description:'phone no',
    // },
  },
};

