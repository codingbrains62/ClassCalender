/**
 * Calendar_event.js
 *
 * @description :: A model definition represents a database table/collection.
 * @docs        :: https://sailsjs.com/docs/concepts/models-and-orm/models
 */

module.exports = {

 attributes: {

    calendar_id: {
      type: 'string',
      description: 'Calendar id ',
    },

    subjectName: {
      type: 'string',
      description: 'This is not an association-- it is another copy of the user id,  in case the user is deleted.',
    },
    startTime: {
      type: 'string',
      description: 'This is not an association-- it is another copy of the user id,  in case the user is deleted.',
    },

    endTime: {
      type: 'string',
      description: 'This is to point the user id to the proper table',
      
    },
    location:{
      type:'json',
      description:'location calendar event ',
    },
    allData:{
      type:'json',
      description:'all calendar data ',

    },
    recurrence:{
      type:'string',
      description:'recurrence ',
    },
    reminderMinutesBeforeStart:{
      type:'string',
      description:'reminderMinutesBeforeStart time',
    },
    isAllDay:{
      type:'boolean',
      description:' isAllDay true or false ',
    },
    isReminderOn:{
      type:'boolean',
      description:'isReminderOn true or false ',
    },
     userid: {
      model:'User',
      description:'user id ',
    },
    email_id: {
      type:'string',
      description:'email ',
    },
    email_subject: {
      type:'string',
      description:'email subject ',
    },
    email_body: {
      type:'string',
      description:'email body ',
    }
  
  },



};

