module.exports.email = {
    service: "gmail",
auth: {
    user:"codingbrains123@gmail.com",
    pass:"testmnbvcxz@1234"
},
templateDir: "api/emailTemplates",
from: "codingbrains123@gmail.com",
testMode:false,
    ssl: false
}