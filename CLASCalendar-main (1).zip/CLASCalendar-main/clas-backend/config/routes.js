/**
 * Route Mappings
 * (sails.config.routes)
 *
 * Your routes tell Sails what to do each time it receives a request.
 *
 * For more information on configuring custom routes, check out:
 * https://sailsjs.com/anatomy/config/routes-js
 */

module.exports.routes = {

  /***************************************************************************
  *                                                                          *
  * Make the view located at `views/homepage.ejs` your home page.            *
  *                                                                          *
  * (Alternatively, remove this and add an `index.html` file in your         *
  * `assets` directory)                                                      *
  *                                                                          *
  ***************************************************************************/

  '/': { view: 'pages/homepage' },

  'POST /login': 'validate-login',
  'POST /forgot_password': 'forgot-password',
  'POST /reset-password': 'reset-login',
  'POST /add-user': 'add-user',
  'GET /view-error-log': 'view-error-logs',
  'GET /view-history-log': 'view-history-log',
  'GET /view-user': 'view-user',
  'GET /view-event': 'view-events',
  'POST /get-events': { action: 'get-calendar-event' },
  'POST /remove-event': { action: 'remove-event' },
  'POST /edit-event': 'edit-event',
  'POST /edit-event': { action: 'edit-event' },
  'POST /remove-user': { action: 'remove-user' },
  'POST /disable-user': { action: 'disable-user' },
  'POST /view-profile': { action: 'view-profile' },
  'POST /edit-user': { action: 'edit-user' },
  'POST /add-event': { action: 'add-event' },
  'POST /update-event': { action: 'update-event' },
  'POST /resume-event': { action: 'resume-event' },
  'POST /pause-event': { action: 'pause-event' },
  'POST /add-calendar-event': { action: 'add-calendar-event' },
  'POST /update-calendar': { action: 'update-calendar-event' },
  'POST /delete-calendar': { action: 'delete-calendar-event' },
  //insert data to database both Api clas trak entity trak
  'POST /clastrak-event': { action: 'clastrak-calendar-event' },
  'POST /entitytrak-event': { action: 'entitytrak-calendar-event' },
  //retrive data from database show on dashboard
  'POST /clastrak-data': { action: 'clastrak-event-data' },
  'POST /entitytrak-data': { action: 'entitytrak-event-data' },
  // new api for eznumfile and idsearch
  'POST /eznum-event': { action: 'eznum-calendar-event' },
  'POST /idsearch-event': { action: 'idsearch-calendar-event' },
   //retrive data from database of new api show on dashboard
   'POST /eznum-get': { action: 'eznum-get-data' },
   'POST /idsearch-get': { action: 'idesearch-get-data' },


   



  /***************************************************************************
  *                                                                          *
  * More custom routes here...                                               *
  * (See https://sailsjs.com/config/routes for examples.)                    *
  *                                                                          *
  * If a request to a URL doesn't match any of the routes in this file, it   *
  * is matched against "shadow routes" (e.g. blueprint routes).  If it does  *
  * not match any of those, it is matched against static assets.             *
  *                                                                          *
  ***************************************************************************/


};
